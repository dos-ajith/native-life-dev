import sqlalchemy as sa
from alembic.operations import Operations

PREFIX = "plg_packages_"


def upgrade(op: Operations) -> None:
    op.add_column(
        f"{PREFIX}packages",
        sa.Column("tax_percent", sa.Numeric(5, 2), server_default="0", nullable=False),
    )
