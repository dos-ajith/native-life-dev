from typing import Any

import sqlalchemy as sa
from alembic.operations import Operations

PREFIX = "plg_packages_"
PACKAGES = f"{PREFIX}packages"
NOW = sa.text("now()")
STATUSES = "'draft', 'pending_approval', 'published', 'unpublished', 'rejected'"
CATEGORIES = "'travel', 'resort'"
PRICING_SOURCES = "'manual', 'business_default'"
APPROVAL_ACTIONS = "'submitted', 'approved', 'rejected'"
PUBLISHED_COMPLETE = (
    "status <> 'published' OR (direct_value IS NOT NULL AND package_price IS NOT NULL "
    "AND primary_location_id IS NOT NULL AND business_id IS NOT NULL)"
)


def _timestamps() -> list[sa.Column[Any]]:
    return [
        sa.Column("created_at", sa.DateTime(), server_default=NOW, nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=NOW, nullable=False),
    ]


def upgrade(op: Operations) -> None:
    op.add_column(
        PACKAGES,
        sa.Column("category", sa.String(20), server_default="travel", nullable=False),
    )
    op.add_column(PACKAGES, sa.Column("origin_name", sa.String(120), nullable=True))
    op.add_column(PACKAGES, sa.Column("origin_latitude", sa.Numeric(9, 6), nullable=True))
    op.add_column(PACKAGES, sa.Column("origin_longitude", sa.Numeric(9, 6), nullable=True))
    op.add_column(PACKAGES, sa.Column("pricing_source", sa.String(20), nullable=True))
    op.alter_column(PACKAGES, "business_id", existing_type=sa.Uuid(), nullable=True)

    op.drop_constraint(f"ck_{PREFIX}packages_status_valid", PACKAGES, type_="check")
    op.create_check_constraint(
        f"ck_{PREFIX}packages_status_valid", PACKAGES, f"status IN ({STATUSES})"
    )
    op.create_check_constraint(
        f"ck_{PREFIX}packages_category_valid", PACKAGES, f"category IN ({CATEGORIES})"
    )
    op.create_check_constraint(
        f"ck_{PREFIX}packages_pricing_source_valid",
        PACKAGES,
        f"pricing_source IS NULL OR pricing_source IN ({PRICING_SOURCES})",
    )
    op.drop_constraint(f"ck_{PREFIX}packages_published_is_complete", PACKAGES, type_="check")
    op.create_check_constraint(
        f"ck_{PREFIX}packages_published_is_complete", PACKAGES, PUBLISHED_COMPLETE
    )

    op.create_table(
        f"{PREFIX}route_points",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column(
            "package_id",
            sa.Uuid(),
            sa.ForeignKey(f"{PACKAGES}.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("latitude", sa.Numeric(9, 6), nullable=False),
        sa.Column("longitude", sa.Numeric(9, 6), nullable=False),
        *_timestamps(),
    )
    op.create_index(f"ix_{PREFIX}route_points_package_id", f"{PREFIX}route_points", ["package_id"])

    op.add_column(
        f"{PREFIX}package_media",
        sa.Column(
            "route_point_id",
            sa.Uuid(),
            sa.ForeignKey(f"{PREFIX}route_points.id", ondelete="CASCADE"),
            nullable=True,
        ),
    )
    op.create_index(
        f"ix_{PREFIX}package_media_route_point_id",
        f"{PREFIX}package_media",
        ["route_point_id"],
    )

    op.create_table(
        f"{PREFIX}approval_events",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column(
            "package_id",
            sa.Uuid(),
            sa.ForeignKey(f"{PACKAGES}.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column(
            "actor_id",
            sa.Uuid(),
            sa.ForeignKey("users.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("note", sa.Text(), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            f"action IN ({APPROVAL_ACTIONS})", name=f"ck_{PREFIX}approval_events_action_valid"
        ),
    )
    op.create_index(
        f"ix_{PREFIX}approval_events_package_id", f"{PREFIX}approval_events", ["package_id"]
    )

    op.create_table(
        f"{PREFIX}business_pricing",
        sa.Column(
            "business_id",
            sa.Uuid(),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column("default_price", sa.Numeric(12, 2), nullable=False),
        *_timestamps(),
        sa.CheckConstraint(
            "default_price > 0", name=f"ck_{PREFIX}business_pricing_default_price_positive"
        ),
    )

    op.execute(
        f"""
        INSERT INTO {PREFIX}route_points
            (id, package_id, sequence, name, latitude, longitude)
        SELECT gen_random_uuid(), package.id, 0, location.name, location.latitude,
               location.longitude
        FROM {PACKAGES} AS package
        JOIN {PREFIX}locations AS location ON location.id = package.primary_location_id
        WHERE location.latitude IS NOT NULL AND location.longitude IS NOT NULL
        """
    )
