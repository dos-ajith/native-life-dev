from typing import Any

import sqlalchemy as sa
from alembic.operations import Operations

PREFIX = "plg_packages_"
NOW = sa.text("now()")
PACKAGE_STATUSES = "'draft', 'published', 'unpublished'"
PACKAGE_TYPES = "'product', 'service', 'activity'"
MEDIA_KINDS = "'image', 'video'"


def _timestamps() -> list[sa.Column[Any]]:
    return [
        sa.Column("created_at", sa.DateTime(), server_default=NOW, nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=NOW, nullable=False),
    ]


def _package_fk(ondelete: str) -> sa.ForeignKey:
    return sa.ForeignKey(f"{PREFIX}packages.id", ondelete=ondelete)


def _location_fk() -> sa.ForeignKey:
    return sa.ForeignKey(f"{PREFIX}locations.id", ondelete="RESTRICT")


def upgrade(op: Operations) -> None:
    op.create_table(
        f"{PREFIX}locations",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("slug", sa.String(140), nullable=False),
        sa.Column("latitude", sa.Numeric(9, 6), nullable=True),
        sa.Column("longitude", sa.Numeric(9, 6), nullable=True),
        *_timestamps(),
        sa.UniqueConstraint("slug", name=f"uq_{PREFIX}locations_slug"),
    )

    op.create_table(
        f"{PREFIX}packages",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column(
            "business_id",
            sa.Uuid(),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "promoter_id",
            sa.Uuid(),
            sa.ForeignKey("users.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("title", sa.String(100), nullable=False),
        sa.Column("description", sa.String(100), nullable=False),
        sa.Column("primary_location_id", sa.Uuid(), _location_fk(), nullable=True),
        sa.Column("youtube_url", sa.String(500), nullable=True),
        sa.Column("extra_content", sa.Text(), nullable=True),
        sa.Column("direct_value", sa.Numeric(12, 2), nullable=True),
        sa.Column("package_price", sa.Numeric(12, 2), nullable=True),
        sa.Column("status", sa.String(20), server_default="draft", nullable=False),
        sa.Column("published_at", sa.DateTime(), nullable=True),
        sa.Column("unpublished_at", sa.DateTime(), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            f"status IN ({PACKAGE_STATUSES})", name=f"ck_{PREFIX}packages_status_valid"
        ),
        sa.CheckConstraint(
            "direct_value IS NULL OR direct_value >= 0",
            name=f"ck_{PREFIX}packages_direct_value_not_negative",
        ),
        sa.CheckConstraint(
            "package_price IS NULL OR package_price >= 0",
            name=f"ck_{PREFIX}packages_package_price_not_negative",
        ),
        sa.CheckConstraint(
            "direct_value IS NULL OR package_price IS NULL OR package_price <= direct_value",
            name=f"ck_{PREFIX}packages_price_within_direct_value",
        ),
        sa.CheckConstraint(
            "status <> 'published' OR (direct_value IS NOT NULL AND package_price IS NOT NULL "
            "AND primary_location_id IS NOT NULL)",
            name=f"ck_{PREFIX}packages_published_is_complete",
        ),
    )
    op.create_index(f"ix_{PREFIX}packages_promoter_id", f"{PREFIX}packages", ["promoter_id"])
    op.create_index(
        f"ix_{PREFIX}packages_status_primary_location",
        f"{PREFIX}packages",
        ["status", "primary_location_id"],
    )
    op.create_index(
        f"ix_{PREFIX}packages_business_status", f"{PREFIX}packages", ["business_id", "status"]
    )

    op.create_table(
        f"{PREFIX}package_types",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("package_id", sa.Uuid(), _package_fk("CASCADE"), nullable=False),
        sa.Column("type", sa.String(20), nullable=False),
        *_timestamps(),
        sa.UniqueConstraint("package_id", "type", name=f"uq_{PREFIX}package_types_package_type"),
        sa.CheckConstraint(f"type IN ({PACKAGE_TYPES})", name=f"ck_{PREFIX}package_types_valid"),
    )

    op.create_table(
        f"{PREFIX}package_media",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("package_id", sa.Uuid(), _package_fk("CASCADE"), nullable=False),
        sa.Column("kind", sa.String(20), nullable=False),
        sa.Column("url", sa.String(500), nullable=False),
        sa.Column("content_type", sa.String(50), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("sort_order", sa.Integer(), server_default="0", nullable=False),
        *_timestamps(),
        sa.CheckConstraint(f"kind IN ({MEDIA_KINDS})", name=f"ck_{PREFIX}package_media_kind"),
    )
    op.create_index(
        f"ix_{PREFIX}package_media_package_sort",
        f"{PREFIX}package_media",
        ["package_id", "sort_order"],
    )

    op.create_table(
        f"{PREFIX}package_inclusions",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("package_id", sa.Uuid(), _package_fk("CASCADE"), nullable=False),
        sa.Column("business_name", sa.String(100), nullable=False),
        sa.Column("provides", sa.String(100), nullable=False),
        sa.Column("sort_order", sa.Integer(), server_default="0", nullable=False),
        *_timestamps(),
    )
    op.create_index(
        f"ix_{PREFIX}package_inclusions_package_id", f"{PREFIX}package_inclusions", ["package_id"]
    )

    op.create_table(
        f"{PREFIX}package_visibility",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("package_id", sa.Uuid(), _package_fk("CASCADE"), nullable=False),
        sa.Column("location_id", sa.Uuid(), _location_fk(), nullable=False),
        *_timestamps(),
        sa.UniqueConstraint(
            "package_id", "location_id", name=f"uq_{PREFIX}package_visibility_package_location"
        ),
    )
    op.create_index(
        f"ix_{PREFIX}package_visibility_location_id",
        f"{PREFIX}package_visibility",
        ["location_id"],
    )

    op.create_table(
        f"{PREFIX}order_links",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("package_id", sa.Uuid(), _package_fk("RESTRICT"), nullable=False),
        sa.Column(
            "business_id",
            sa.Uuid(),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("order_id", sa.Uuid(), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("direct_value", sa.Numeric(12, 2), nullable=False),
        sa.Column("package_price", sa.Numeric(12, 2), nullable=False),
        *_timestamps(),
        sa.UniqueConstraint("order_id", "package_id", name=f"uq_{PREFIX}order_links_order_package"),
        sa.CheckConstraint("quantity >= 1", name=f"ck_{PREFIX}order_links_quantity_positive"),
        sa.CheckConstraint(
            "package_price >= 0 AND package_price <= direct_value",
            name=f"ck_{PREFIX}order_links_price_within_direct_value",
        ),
    )
    op.create_index(f"ix_{PREFIX}order_links_package_id", f"{PREFIX}order_links", ["package_id"])
    op.create_index(
        f"ix_{PREFIX}order_links_business_created",
        f"{PREFIX}order_links",
        ["business_id", "created_at"],
    )
