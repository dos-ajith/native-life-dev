import sqlalchemy as sa
from alembic.operations import Operations

PREFIX = "plg_packages_"
NOW = sa.text("now()")


def upgrade(op: Operations) -> None:
    op.create_table(
        f"{PREFIX}business_config",
        sa.Column(
            "business_id",
            sa.Uuid(),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column("category", sa.String(20), nullable=False),
        sa.Column("created_at", sa.DateTime(), server_default=NOW, nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=NOW, nullable=False),
        sa.CheckConstraint(
            "category IN ('travel', 'resort')", name=f"ck_{PREFIX}business_config_category_valid"
        ),
    )
