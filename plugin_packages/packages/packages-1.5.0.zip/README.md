# Packages plugin

Travel and Resort packages (`plugins/service/packages`), v1.4.1.

- Categories: the manifest binds the Service root exactly (so a verified Service business created under just "Service" is offered the plugin), and Travel (`business-service-travel-tours`) and Resorts (`business-service-hotels-stays`) with descendants. Other Service leaf categories and Product businesses are refused by the framework.
- Business category: after enabling the plugin the owner chooses Travel or Resorts (`GET`/`PUT /businesses/{id}/package-category`, saved in `plg_packages_business_config`). A business already inside the Travel or Resorts category uses that category and cannot choose the other. The choice is locked once the business has packages. Until it is set, package creation is refused. The effective category (category chain first, then the saved choice) is what owner creation, Promoter business lists, business selection and submit all validate against.
- Manifest: `plugin.toml` (key `packages`, tables `plg_packages_*`, API prefix `/api/v1/plugins/packages`, needs core API `>=1.9,<2.0`).
- Backend: `backend/` (models, schemas, repositories, services, routes, `plugin.py`).
- Migrations: `migrations/NNNN_name.py` (`upgrade(op)`). `0002` is additive: it keeps every package, media row and order link, and backfills one destination from the primary location when that location has coordinates. The old `package_types` table is no longer used by the code and is kept until a later migration drops it.
- Seeders: `0001` grants view, manage and orders to the Promoter and Business / Service Provider, and view and orders to Native Admin and Super Admin.

## Wizard

1. **Information:** title, description and the destinations. Travel needs 2 to 20 ordered pins (the route line connects them in order); a resort needs exactly one pin. Names come from the map and can be edited. A resort also stores the creator's native place as the start of its route (set by the server, never by the client).
2. **Media:** JPG, PNG or MP4 per location (up to 10 files each, 50 MB each). Travel needs at least one file for every location. Optional YouTube link and extra content.
3. **Business:** a Promoter picks a business from `GET /promoter/businesses?category=` (native-place discovery, plugin enabled, same category). An owner already has the business. Optional inclusions (what each business provides).
4. **Pricing:** `source` is `business_default` (the owner-set default price is the original price, the Promoter sets the offer) or `manual`. The offer cannot exceed the original price. `tax_percent` (0-100, default 0) is the GST % charged on top of the offer price; a booking snapshots it, and the payment link charges offer × party size + tax. The order link still snapshots both prices when an order is placed.
5. **Visibility:** the primary listing location plus extra listing locations, used only for Explore listing. They are separate from the destinations.
6. **Preview and submit.**

## Approval

- A Promoter cannot publish. `POST /promoter/packages/{id}/submit` checks every publish requirement, moves a draft or rejected package to `pending_approval`, records the event and notifies the business owner (in-app, WebSocket, browser push and email through core).
- Only the owner of the package's business can `POST .../approve` (publishes, subject to the same checks) or `POST .../reject` (a note is required). Duplicates return 409, and notifications are only sent after the state change is committed.
- A pending package is locked for everyone. A Promoter can edit only draft or rejected packages and sees the rejection note and history. Owners publish their own drafts directly, and can republish an unpublished package; another Promoter's draft must go through approval.

## Endpoints

Owner, under `/businesses/{business_id}`: `package-locations`, `packages` (`tab=active|inactive|pending`), `packages/{id}` plus `information`, `media` (form field `route_point_id`), `media/order`, `media/{media_id}`, `extras`, `inclusions`, `pricing`, `visibility`, `preview`, `publish`, `unpublish`, `approve`, `reject`, `orders`, and `package-default-price` (GET, PUT), `package-orders`.

Promoter, under `/promoter` (all routes require the verified `promoter` role; a business owner or admin gets 403): `businesses`, `package-locations`, `packages` (create takes `category` and the pins, no business), `packages/{id}` with the same sub-paths, `business` (PUT, step 3) and `submit`; there is no `publish`.

Customer, under `/explore`: `categories` (Travel and Resorts with published package counts, used by the Services tile), `locations`, `packages?location_id=&category=`, `packages/{id}`.

Bookings: packages are booked, not ordered. The plugin registers a booking provider (`backend/booking_provider.py`) and core's Bookings module does the rest: a customer requests a booking with `POST /api/v1/businesses/{business_id}/bookings` (package id as `item_id`, dates, party size, contact details), the business owner confirms or rejects it under `/api/v1/me/businesses/{business_id}/bookings`, and either side can cancel until it is completed. Only published, priced packages can be booked, and the price and offer are snapshotted on the booking. Packages are no longer registered for core cart, checkout or deals. `plg_packages_order_links` and the `package-orders` routes stay as read-only history of orders placed before bookings.

Tests: `pytest plugins/service/packages/tests` (SQLite) and `PACKAGES_TEST_PG=1 pytest plugins/service/packages/tests` (Postgres).
