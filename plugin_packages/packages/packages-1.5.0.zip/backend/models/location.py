from decimal import Decimal

from sqlalchemy import Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from app.plugins.sdk import TimestampMixin, UUIDPrimaryKeyMixin

from ..config import LOCATION_NAME_MAX_LENGTH, LOCATION_SLUG_MAX_LENGTH
from .base import PackagesBase


class Location(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_locations"

    name: Mapped[str] = mapped_column(String(LOCATION_NAME_MAX_LENGTH))
    slug: Mapped[str] = mapped_column(String(LOCATION_SLUG_MAX_LENGTH))
    latitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6), default=None)
    longitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6), default=None)
