from sqlalchemy.orm import DeclarativeBase


class PackagesBase(DeclarativeBase):
    pass
