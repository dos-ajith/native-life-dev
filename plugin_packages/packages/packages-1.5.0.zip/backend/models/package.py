import enum
import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.plugins.sdk import TimestampMixin, UUIDPrimaryKeyMixin

from ..config import (
    APPROVAL_ACTION_MAX_LENGTH,
    CATEGORY_MAX_LENGTH,
    DESCRIPTION_MAX_LENGTH,
    INCLUSION_TEXT_MAX_LENGTH,
    LOCATION_NAME_MAX_LENGTH,
    MEDIA_CONTENT_TYPE_MAX_LENGTH,
    MEDIA_URL_MAX_LENGTH,
    PRICING_SOURCE_MAX_LENGTH,
    STATUS_MAX_LENGTH,
    TITLE_MAX_LENGTH,
    TYPE_MAX_LENGTH,
    YOUTUBE_URL_MAX_LENGTH,
)
from .base import PackagesBase
from .location import Location


class PackageStatus(enum.StrEnum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    PUBLISHED = "published"
    UNPUBLISHED = "unpublished"
    REJECTED = "rejected"


class PackageCategory(enum.StrEnum):
    TRAVEL = "travel"
    RESORT = "resort"


class PricingSource(enum.StrEnum):
    MANUAL = "manual"
    BUSINESS_DEFAULT = "business_default"


class ApprovalAction(enum.StrEnum):
    SUBMITTED = "submitted"
    APPROVED = "approved"
    REJECTED = "rejected"


class MediaKind(enum.StrEnum):
    IMAGE = "image"
    VIDEO = "video"


class RoutePoint(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_route_points"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="CASCADE")
    )
    sequence: Mapped[int]
    name: Mapped[str] = mapped_column(String(LOCATION_NAME_MAX_LENGTH))
    latitude: Mapped[Decimal] = mapped_column(Numeric(9, 6))
    longitude: Mapped[Decimal] = mapped_column(Numeric(9, 6))


class PackageMedia(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_package_media"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="CASCADE")
    )
    route_point_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("plg_packages_route_points.id", ondelete="CASCADE"), default=None
    )
    kind: Mapped[str] = mapped_column(String(TYPE_MAX_LENGTH))
    url: Mapped[str] = mapped_column(String(MEDIA_URL_MAX_LENGTH))
    content_type: Mapped[str] = mapped_column(String(MEDIA_CONTENT_TYPE_MAX_LENGTH))
    size_bytes: Mapped[int]
    sort_order: Mapped[int] = mapped_column(default=0)


class PackageInclusion(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_package_inclusions"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="CASCADE")
    )
    business_name: Mapped[str] = mapped_column(String(INCLUSION_TEXT_MAX_LENGTH))
    provides: Mapped[str] = mapped_column(String(INCLUSION_TEXT_MAX_LENGTH))
    sort_order: Mapped[int] = mapped_column(default=0)


class PackageVisibility(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_package_visibility"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="CASCADE")
    )
    location_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_locations.id", ondelete="RESTRICT")
    )

    location: Mapped[Location] = relationship(lazy="joined")


class PackageApprovalEvent(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_approval_events"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="CASCADE")
    )
    action: Mapped[str] = mapped_column(String(APPROVAL_ACTION_MAX_LENGTH))
    actor_id: Mapped[uuid.UUID | None] = mapped_column(default=None)
    note: Mapped[str | None] = mapped_column(Text, default=None)


class BusinessPricing(PackagesBase, TimestampMixin):
    __tablename__ = "plg_packages_business_pricing"

    business_id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    default_price: Mapped[Decimal] = mapped_column(Numeric(12, 2))


class BusinessPackageConfig(PackagesBase, TimestampMixin):
    __tablename__ = "plg_packages_business_config"

    business_id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    category: Mapped[str] = mapped_column(String(CATEGORY_MAX_LENGTH))


class Package(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_packages"

    business_id: Mapped[uuid.UUID | None] = mapped_column(default=None)
    promoter_id: Mapped[uuid.UUID | None] = mapped_column(default=None)
    category: Mapped[str] = mapped_column(
        String(CATEGORY_MAX_LENGTH),
        default=PackageCategory.TRAVEL,
        server_default=PackageCategory.TRAVEL,
    )
    title: Mapped[str] = mapped_column(String(TITLE_MAX_LENGTH))
    description: Mapped[str] = mapped_column(String(DESCRIPTION_MAX_LENGTH))
    primary_location_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("plg_packages_locations.id", ondelete="RESTRICT"), default=None
    )
    origin_name: Mapped[str | None] = mapped_column(String(LOCATION_NAME_MAX_LENGTH), default=None)
    origin_latitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6), default=None)
    origin_longitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6), default=None)
    youtube_url: Mapped[str | None] = mapped_column(String(YOUTUBE_URL_MAX_LENGTH), default=None)
    extra_content: Mapped[str | None] = mapped_column(Text, default=None)
    pricing_source: Mapped[str | None] = mapped_column(
        String(PRICING_SOURCE_MAX_LENGTH), default=None
    )
    direct_value: Mapped[Decimal | None] = mapped_column(Numeric(12, 2), default=None)
    package_price: Mapped[Decimal | None] = mapped_column(Numeric(12, 2), default=None)
    tax_percent: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), default=Decimal(0), server_default="0"
    )
    status: Mapped[str] = mapped_column(
        String(STATUS_MAX_LENGTH), default=PackageStatus.DRAFT, server_default=PackageStatus.DRAFT
    )
    published_at: Mapped[datetime | None] = mapped_column(default=None)
    unpublished_at: Mapped[datetime | None] = mapped_column(default=None)

    primary_location: Mapped[Location | None] = relationship(lazy="joined")
    route_points: Mapped[list[RoutePoint]] = relationship(
        order_by="RoutePoint.sequence", lazy="selectin", cascade="all, delete-orphan"
    )
    media: Mapped[list[PackageMedia]] = relationship(
        order_by="PackageMedia.sort_order, PackageMedia.created_at",
        lazy="selectin",
        cascade="all, delete-orphan",
    )
    inclusions: Mapped[list[PackageInclusion]] = relationship(
        order_by="PackageInclusion.sort_order, PackageInclusion.created_at",
        lazy="selectin",
        cascade="all, delete-orphan",
    )
    visibility: Mapped[list[PackageVisibility]] = relationship(
        lazy="selectin", cascade="all, delete-orphan"
    )
    approval_events: Mapped[list[PackageApprovalEvent]] = relationship(
        order_by="PackageApprovalEvent.created_at, PackageApprovalEvent.id",
        lazy="selectin",
        cascade="all, delete-orphan",
    )
    business_pricing: Mapped[BusinessPricing | None] = relationship(
        primaryjoin="foreign(Package.business_id) == BusinessPricing.business_id",
        viewonly=True,
        lazy="selectin",
        uselist=False,
    )


class PackageOrderLink(PackagesBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_packages_order_links"

    package_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("plg_packages_packages.id", ondelete="RESTRICT")
    )
    business_id: Mapped[uuid.UUID]
    order_id: Mapped[uuid.UUID]
    quantity: Mapped[int]
    direct_value: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    package_price: Mapped[Decimal] = mapped_column(Numeric(12, 2))
