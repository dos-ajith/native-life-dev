from uuid import UUID

from .config import MAX_ROUTE_POINTS, MIN_TRAVEL_ROUTE_POINTS
from .models import Package, PackageCategory, PackageMedia


def route_point_count_valid(category: str, count: int) -> bool:
    if category == PackageCategory.RESORT:
        return count == 1
    return MIN_TRAVEL_ROUTE_POINTS <= count <= MAX_ROUTE_POINTS


def points_without_media(package: Package) -> list[str]:
    covered = {item.route_point_id for item in package.media}
    return [point.name for point in package.route_points if point.id not in covered]


def media_complete(package: Package) -> bool:
    if not package.media:
        return False
    if package.category == PackageCategory.RESORT:
        return True
    return not points_without_media(package)


def _sequence(sequence_by_point: dict[UUID, int], item: PackageMedia) -> int:
    if item.route_point_id is None:
        return -1
    return sequence_by_point.get(item.route_point_id, -1)


def ordered_media(package: Package) -> list[PackageMedia]:
    sequence_by_point = {point.id: point.sequence for point in package.route_points}
    return sorted(
        package.media,
        key=lambda item: (_sequence(sequence_by_point, item), item.sort_order),
    )


def cover_url(package: Package) -> str | None:
    media = ordered_media(package)
    return media[0].url if media else None
