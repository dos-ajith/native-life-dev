from app.plugins.sdk import PluginContext

from .booking_provider import PackagesBookingProvider
from .models import PackagesBase
from .routes import ROUTERS


def register(ctx: PluginContext) -> None:
    ctx.register_models(PackagesBase)
    ctx.register_booking_provider(PackagesBookingProvider())
    for router in ROUTERS:
        ctx.include_router(router)
