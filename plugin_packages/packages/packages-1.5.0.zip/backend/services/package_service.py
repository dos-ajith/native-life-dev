from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import (
    AuthorizationError,
    BusinessRuleError,
    Page,
    PaginationParams,
    User,
    find_native_origin,
    find_plugin_business,
)

from ..activity_actions import PackageAction
from ..messages import PackageMessages
from ..models import Package, PackageCategory, PackageStatus
from ..repositories.package_repository import PackageRepository
from ..schemas.package import (
    PackageDetail,
    PackageInformation,
    PackageRead,
    PackageSummary,
    PackageTab,
)
from .category_service import require_business_category
from .media_service import discard_media_files
from .package_activity import log_package
from .package_lookup import require_package
from .route_point_service import apply_route_points, ensure_route_point_count

COORDINATE_DIGITS = 6

TAB_STATUSES = {
    PackageTab.ACTIVE: (PackageStatus.PUBLISHED,),
    PackageTab.INACTIVE: (PackageStatus.DRAFT, PackageStatus.UNPUBLISHED, PackageStatus.REJECTED),
    PackageTab.PENDING: (PackageStatus.PENDING_APPROVAL,),
}


class PackageService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._packages = PackageRepository(db)

    def get(self, business_id: UUID | None, package_id: UUID) -> PackageRead:
        package = require_package(self._db, business_id, package_id)
        return PackageRead.from_model(package).model_copy(
            update={"business_name": self._business_name(package)}
        )

    def preview(self, business_id: UUID | None, package_id: UUID) -> PackageDetail:
        package = require_package(self._db, business_id, package_id)
        return PackageDetail.from_model(package).model_copy(
            update={"business_name": self._business_name(package)}
        )

    def list_page(
        self,
        business_id: UUID,
        owner_id: UUID,
        tab: PackageTab,
        params: PaginationParams,
    ) -> Page[PackageSummary]:
        items, total = self._packages.list_for_business(
            business_id,
            owner_id,
            TAB_STATUSES[tab],
            (params.page - 1) * params.page_size,
            params.page_size,
        )
        return Page[PackageSummary].create(
            [PackageSummary.from_model(item) for item in items], total, params
        )

    def create_for_business(
        self, business_id: UUID, owner_id: UUID, payload: PackageInformation, actor: User
    ) -> PackageRead:
        if owner_id != actor.id:
            raise AuthorizationError(PackageMessages.NOT_YOUR_BUSINESS)
        category = require_business_category(self._db, business_id)
        return self.create_draft(business_id, category, payload, actor)

    def create_draft(
        self,
        business_id: UUID | None,
        category: PackageCategory,
        payload: PackageInformation,
        actor: User,
    ) -> PackageRead:
        ensure_route_point_count(category, len(payload.route_points))
        package = self._packages.add(
            Package(
                business_id=business_id,
                promoter_id=actor.id,
                category=category,
                title=payload.title,
                description=payload.description,
            )
        )
        apply_route_points(package, payload.route_points)
        self._apply_origin(package, actor)
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_CREATED, package)
        return self.get(business_id, package.id)

    def update_information(
        self, business_id: UUID | None, package_id: UUID, payload: PackageInformation, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        ensure_route_point_count(package.category, len(payload.route_points))
        removed_media = apply_route_points(package, payload.route_points)
        if package.status == PackageStatus.PUBLISHED and not package.media:
            self._db.rollback()
            raise BusinessRuleError(PackageMessages.ROUTE_POINT_REMOVAL_EMPTIES_PUBLISHED)
        package.title = payload.title
        package.description = payload.description
        self._apply_origin(package, actor)
        self._db.commit()
        discard_media_files(removed_media)
        log_package(self._db, actor, PackageAction.INFORMATION_UPDATED, package)
        return self.get(business_id, package_id)

    def _apply_origin(self, package: Package, actor: User) -> None:
        if package.category != PackageCategory.RESORT:
            package.origin_name = None
            package.origin_latitude = None
            package.origin_longitude = None
            return
        origin = find_native_origin(self._db, actor)
        if origin is None:
            return
        package.origin_name = origin.name
        package.origin_latitude = Decimal(str(round(origin.latitude, COORDINATE_DIGITS)))
        package.origin_longitude = Decimal(str(round(origin.longitude, COORDINATE_DIGITS)))

    def _business_name(self, package: Package) -> str | None:
        if package.business_id is None:
            return None
        business = find_plugin_business(self._db, package.business_id)
        return business.name if business is not None else None
