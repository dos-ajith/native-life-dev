from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import NotFoundError, Page, PaginationParams

from ..messages import PackageMessages
from ..models import PackageCategory
from ..repositories.location_repository import LocationRepository
from ..repositories.package_repository import PackageRepository
from ..schemas.location import ExploreLocationRead, LocationRead
from ..schemas.package import ExploreCategoryRead, ExplorePackageSummary, PackageDetail
from .location_service import require_locations

CATEGORY_NAMES = {PackageCategory.TRAVEL: "Travel", PackageCategory.RESORT: "Resorts"}


class ExploreService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._packages = PackageRepository(db)
        self._locations = LocationRepository(db)

    def list_categories(self) -> list[ExploreCategoryRead]:
        counts = self._packages.count_published_by_category()
        return [
            ExploreCategoryRead(id=category, name=name, package_count=counts.get(category, 0))
            for category, name in CATEGORY_NAMES.items()
        ]

    def list_locations(
        self, params: PaginationParams, search: str | None
    ) -> Page[ExploreLocationRead]:
        rows, total = self._locations.list_with_published_packages(
            search, (params.page - 1) * params.page_size, params.page_size
        )
        return Page[ExploreLocationRead].create(
            [
                ExploreLocationRead(
                    **LocationRead.model_validate(location).model_dump(), package_count=count
                )
                for location, count in rows
            ],
            total,
            params,
        )

    def list_packages(
        self,
        params: PaginationParams,
        location_id: UUID | None,
        category: PackageCategory | None,
        search: str | None,
    ) -> Page[ExplorePackageSummary]:
        if location_id is not None:
            require_locations(self._db, [location_id])
        items, total = self._packages.list_published(
            location_id,
            category,
            search,
            (params.page - 1) * params.page_size,
            params.page_size,
        )
        return Page[ExplorePackageSummary].create(
            [ExplorePackageSummary.from_model(item) for item in items], total, params
        )

    def get(self, package_id: UUID) -> PackageDetail:
        package = self._packages.get_published(package_id)
        if package is None:
            raise NotFoundError(PackageMessages.PACKAGE_NOT_FOUND)
        return PackageDetail.from_model(package)
