import re
from collections.abc import Collection
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.plugins.sdk import (
    BusinessRuleError,
    ConflictError,
    NotFoundError,
    Page,
    PaginationParams,
    User,
    record_activity,
)

from ..activity_actions import PackageAction, PackageEntity
from ..config import LOCATION_SLUG_MAX_LENGTH
from ..database_errors import is_unique_violation
from ..messages import PackageMessages
from ..models import Location
from ..repositories.location_repository import LocationRepository
from ..schemas.location import LocationCreate, LocationRead

SLUG_SEPARATOR_PATTERN = re.compile(r"[^a-z0-9]+")


def _slugify(name: str) -> str:
    return SLUG_SEPARATOR_PATTERN.sub("-", name.lower()).strip("-")


def require_locations(db: Session, location_ids: Collection[UUID]) -> dict[UUID, Location]:
    wanted = set(location_ids)
    found = {location.id: location for location in LocationRepository(db).get_many(wanted)}
    if found.keys() != wanted:
        raise NotFoundError(PackageMessages.LOCATION_NOT_FOUND)
    return found


class LocationService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._locations = LocationRepository(db)

    def list_page(self, params: PaginationParams, search: str | None) -> Page[LocationRead]:
        items, total = self._locations.list_locations(
            search, (params.page - 1) * params.page_size, params.page_size
        )
        return Page[LocationRead].create(
            [LocationRead.model_validate(item) for item in items], total, params
        )

    def create(self, payload: LocationCreate, actor: User) -> LocationRead:
        slug = _slugify(payload.name)[:LOCATION_SLUG_MAX_LENGTH].strip("-")
        if not slug:
            raise BusinessRuleError(PackageMessages.LOCATION_NAME_INVALID)
        if self._locations.get_by_slug(slug) is not None:
            raise ConflictError(PackageMessages.LOCATION_EXISTS)
        location = self._locations.add(
            Location(
                name=payload.name,
                slug=slug,
                latitude=payload.latitude,
                longitude=payload.longitude,
            )
        )
        try:
            self._db.commit()
        except IntegrityError as exc:
            self._db.rollback()
            if not is_unique_violation(exc):
                raise
            raise ConflictError(PackageMessages.LOCATION_EXISTS) from exc
        record_activity(
            self._db,
            actor,
            PackageAction.LOCATION_CREATED,
            PackageEntity.LOCATION,
            location.id,
            {"slug": slug},
        )
        return LocationRead.model_validate(location)
