from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import ConflictError, NotFoundError

from ..messages import PackageMessages
from ..models import Package, PackageStatus
from ..repositories.package_repository import PackageRepository

PROMOTER_EDITABLE_STATUSES = frozenset({PackageStatus.DRAFT, PackageStatus.REJECTED})


def require_package(
    db: Session,
    business_id: UUID | None,
    package_id: UUID,
    for_update: bool = False,
    editable: bool = False,
) -> Package:
    package = PackageRepository(db).get(business_id, package_id, for_update)
    if package is None:
        raise NotFoundError(PackageMessages.PACKAGE_NOT_FOUND)
    if editable and package.status == PackageStatus.PENDING_APPROVAL:
        db.rollback()
        raise ConflictError(PackageMessages.PACKAGE_UNDER_REVIEW)
    return package


def require_own_package(db: Session, promoter_id: UUID, package_id: UUID) -> Package:
    package = PackageRepository(db).get_for_promoter(promoter_id, package_id)
    if package is None:
        raise NotFoundError(PackageMessages.PACKAGE_NOT_FOUND)
    return package


def require_own_editable_package(db: Session, promoter_id: UUID, package_id: UUID) -> Package:
    package = require_own_package(db, promoter_id, package_id)
    if package.status == PackageStatus.PENDING_APPROVAL:
        raise ConflictError(PackageMessages.PACKAGE_UNDER_REVIEW)
    if package.status not in PROMOTER_EDITABLE_STATUSES:
        raise ConflictError(PackageMessages.PACKAGE_NOT_EDITABLE)
    return package
