from datetime import datetime
from uuid import UUID

from fastapi import BackgroundTasks
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.plugins.sdk import (
    AuthorizationError,
    BusinessRuleError,
    ConflictError,
    NotFoundError,
    PluginBusiness,
    User,
    find_plugin_business,
    notify_approval_decided,
    notify_approval_requested,
)

from ..activity_actions import PackageAction, PackageEntity
from ..messages import PackageMessages
from ..models import ApprovalAction, Package, PackageApprovalEvent, PackageStatus
from ..publish_rules import publish_blockers
from ..schemas.package import PackageRead, RejectionInput
from .category_service import business_categories
from .package_activity import log_package
from .package_lookup import PROMOTER_EDITABLE_STATUSES, require_own_package, require_package

SUBMITTABLE_STATUSES = PROMOTER_EDITABLE_STATUSES


class PackageApprovalService:
    def __init__(self, db: Session, background_tasks: BackgroundTasks) -> None:
        self._db = db
        self._background_tasks = background_tasks

    def submit(self, actor: User, package_id: UUID) -> PackageRead:
        package = require_own_package(self._db, actor.id, package_id)
        locked = require_package(self._db, package.business_id, package_id, for_update=True)
        if locked.status not in SUBMITTABLE_STATUSES:
            self._db.rollback()
            raise ConflictError(PackageMessages.NOT_SUBMITTABLE)
        blockers = publish_blockers(locked)
        if blockers:
            self._db.rollback()
            raise BusinessRuleError(PackageMessages.NOT_READY_TO_SUBMIT, blockers)
        self._ensure_business_matches(locked)
        locked.status = PackageStatus.PENDING_APPROVAL
        self._record(locked, ApprovalAction.SUBMITTED, actor, None)
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_SUBMITTED, locked)
        self._notify_owner(locked, actor)
        return PackageRead.from_model(require_package(self._db, locked.business_id, package_id))

    def _ensure_business_matches(self, package: Package) -> None:
        if package.business_id is None:
            return
        current = business_categories(self._db, [package.business_id]).get(package.business_id)
        if current != package.category:
            self._db.rollback()
            raise ConflictError(PackageMessages.BUSINESS_CATEGORY_CHANGED)

    def approve(self, business: PluginBusiness, package_id: UUID, actor: User) -> PackageRead:
        package = self._lock_pending(business, package_id, actor)
        blockers = publish_blockers(package)
        if blockers:
            self._db.rollback()
            raise BusinessRuleError(PackageMessages.NOT_READY_TO_PUBLISH, blockers)
        package.status = PackageStatus.PUBLISHED
        package.published_at = func.now()
        package.unpublished_at = None
        self._record(package, ApprovalAction.APPROVED, actor, None)
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_APPROVED, package)
        self._notify_promoter(package, actor, True, None)
        return PackageRead.from_model(require_package(self._db, business.id, package_id))

    def reject(
        self, business: PluginBusiness, package_id: UUID, payload: RejectionInput, actor: User
    ) -> PackageRead:
        package = self._lock_pending(business, package_id, actor)
        package.status = PackageStatus.REJECTED
        self._record(package, ApprovalAction.REJECTED, actor, payload.note)
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_REJECTED, package)
        self._notify_promoter(package, actor, False, payload.note)
        return PackageRead.from_model(require_package(self._db, business.id, package_id))

    def _lock_pending(self, business: PluginBusiness, package_id: UUID, actor: User) -> Package:
        if business.owner_id != actor.id:
            raise AuthorizationError(PackageMessages.NOT_BUSINESS_OWNER)
        package = require_package(self._db, business.id, package_id, for_update=True)
        if package.status != PackageStatus.PENDING_APPROVAL:
            self._db.rollback()
            raise ConflictError(PackageMessages.NOT_AWAITING_APPROVAL)
        return package

    def _record(
        self, package: Package, action: ApprovalAction, actor: User, note: str | None
    ) -> None:
        package.approval_events.append(
            PackageApprovalEvent(
                action=action, actor_id=actor.id, note=note, created_at=datetime.now()
            )
        )

    def _notify_owner(self, package: Package, actor: User) -> None:
        if package.business_id is None:
            return
        business = find_plugin_business(self._db, package.business_id)
        if business is None:
            raise NotFoundError(PackageMessages.BUSINESS_OWNER_NOT_FOUND)
        notify_approval_requested(
            self._db,
            self._background_tasks,
            actor,
            business.owner_id,
            PackageEntity.PACKAGE,
            package.id,
            package.title,
        )

    def _notify_promoter(
        self, package: Package, actor: User, approved: bool, note: str | None
    ) -> None:
        if package.promoter_id is None:
            return
        notify_approval_decided(
            self._db,
            actor,
            package.promoter_id,
            PackageEntity.PACKAGE,
            package.id,
            package.title,
            approved,
            note,
        )
