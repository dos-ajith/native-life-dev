from sqlalchemy.orm import Session

from app.plugins.sdk import User, record_activity

from ..activity_actions import PackageEntity
from ..models import Package


def log_package(
    db: Session,
    actor: User,
    action: str,
    package: Package,
    extra: dict[str, object] | None = None,
) -> None:
    record_activity(
        db,
        actor,
        action,
        PackageEntity.PACKAGE,
        package.id,
        {"business_id": str(package.business_id), **(extra or {})},
    )
