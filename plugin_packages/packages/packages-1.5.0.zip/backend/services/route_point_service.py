from collections.abc import Sequence

from app.plugins.sdk import BusinessRuleError

from ..config import MAX_ROUTE_POINTS, MIN_TRAVEL_ROUTE_POINTS
from ..messages import PackageMessages
from ..models import Package, PackageMedia, RoutePoint
from ..route_rules import route_point_count_valid
from ..schemas.package import RoutePointInput


def ensure_route_point_count(category: str, count: int) -> None:
    if route_point_count_valid(category, count):
        return
    if category == "resort":
        raise BusinessRuleError(PackageMessages.ROUTE_POINTS_RESORT_INVALID)
    raise BusinessRuleError(
        PackageMessages.ROUTE_POINTS_TRAVEL_INVALID.format(
            minimum=MIN_TRAVEL_ROUTE_POINTS, maximum=MAX_ROUTE_POINTS
        )
    )


def apply_route_points(package: Package, wanted: Sequence[RoutePointInput]) -> list[PackageMedia]:
    existing = {point.id: point for point in package.route_points}
    ordered: list[RoutePoint] = []
    for sequence, item in enumerate(wanted):
        if item.id is None:
            ordered.append(
                RoutePoint(
                    package_id=package.id,
                    sequence=sequence,
                    name=item.name,
                    latitude=item.latitude,
                    longitude=item.longitude,
                )
            )
            continue
        point = existing.get(item.id)
        if point is None:
            raise BusinessRuleError(PackageMessages.ROUTE_POINT_NOT_FOUND)
        point.sequence = sequence
        point.name = item.name
        point.latitude = item.latitude
        point.longitude = item.longitude
        ordered.append(point)
    removed_ids = existing.keys() - {point.id for point in ordered}
    removed_media = [item for item in package.media if item.route_point_id in removed_ids]
    package.media = [item for item in package.media if item not in removed_media]
    package.route_points = ordered
    return removed_media
