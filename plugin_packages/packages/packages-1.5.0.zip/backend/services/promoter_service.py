from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import (
    AuthorizationError,
    BusinessRuleError,
    NativeBusinessScope,
    Page,
    PaginationParams,
    User,
    find_businesses_near_native_places,
)

from ..activity_actions import PackageAction
from ..config import PLUGIN_KEY
from ..messages import PackageMessages
from ..models import PackageCategory, PricingSource
from ..repositories.business_pricing_repository import BusinessPricingRepository
from ..repositories.package_repository import PackageRepository
from ..schemas.package import PackageRead, PackageSummary, PackageTab
from ..schemas.promoter import PromoterBusinessesRead, PromoterBusinessRead, PromoterPackageCreate
from .category_service import business_categories
from .package_activity import log_package
from .package_lookup import require_own_editable_package
from .package_service import TAB_STATUSES, PackageService


def _scope(db: Session, actor: User) -> NativeBusinessScope:
    return find_businesses_near_native_places(db, actor, PLUGIN_KEY)


class PromoterPackageService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._packages = PackageRepository(db)

    def available_businesses(
        self, actor: User, category: PackageCategory | None
    ) -> PromoterBusinessesRead:
        scope = _scope(self._db, actor)
        categories = business_categories(self._db, [item.id for item in scope.businesses])
        defaults = BusinessPricingRepository(self._db).default_prices(
            [item.id for item in scope.businesses]
        )
        return PromoterBusinessesRead(
            has_native_place=scope.has_native_place,
            businesses=[
                PromoterBusinessRead(
                    id=item.id,
                    name=item.name,
                    distance_km=item.distance_km,
                    description=item.description,
                    category=found,
                    default_price=defaults.get(item.id),
                )
                for item in scope.businesses
                if (found := categories.get(item.id)) is not None
                and (category is None or found == category)
            ],
        )

    def create_draft(self, actor: User, payload: PromoterPackageCreate) -> PackageRead:
        if not _scope(self._db, actor).has_native_place:
            raise BusinessRuleError(PackageMessages.NATIVE_PLACE_REQUIRED)
        return PackageService(self._db).create_draft(None, payload.category, payload, actor)

    def select_business(self, actor: User, package_id: UUID, business_id: UUID) -> PackageRead:
        package = require_own_editable_package(self._db, actor.id, package_id)
        eligible = {
            item.id
            for item in self.available_businesses(
                actor, PackageCategory(package.category)
            ).businesses
        }
        if business_id not in eligible:
            raise AuthorizationError(PackageMessages.BUSINESS_NOT_AVAILABLE)
        if (
            package.business_id != business_id
            and package.pricing_source == PricingSource.BUSINESS_DEFAULT
        ):
            package.pricing_source = None
            package.direct_value = None
            package.package_price = None
        package.business_id = business_id
        self._db.commit()
        log_package(self._db, actor, PackageAction.BUSINESS_SELECTED, package)
        return PackageService(self._db).get(business_id, package_id)

    def list_page(
        self, actor: User, tab: PackageTab, params: PaginationParams
    ) -> Page[PackageSummary]:
        items, total = self._packages.list_for_promoter(
            actor.id,
            TAB_STATUSES[tab],
            (params.page - 1) * params.page_size,
            params.page_size,
        )
        return Page[PackageSummary].create(
            [PackageSummary.from_model(item) for item in items], total, params
        )
