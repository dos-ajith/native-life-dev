from uuid import UUID

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.plugins.sdk import BusinessRuleError, User

from ..activity_actions import PackageAction
from ..messages import PackageMessages
from ..models import Package, PackageStatus
from ..publish_rules import publish_blockers
from ..schemas.package import PackageRead
from .package_activity import log_package
from .package_lookup import require_package


class PublishingService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def publish(
        self, business_id: UUID, owner_id: UUID, package_id: UUID, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, for_update=True)
        if package.status == PackageStatus.PUBLISHED:
            self._db.rollback()
            return PackageRead.from_model(require_package(self._db, business_id, package_id))
        self._ensure_directly_publishable(package, owner_id)
        blockers = publish_blockers(package)
        if blockers:
            self._db.rollback()
            raise BusinessRuleError(PackageMessages.NOT_READY_TO_PUBLISH, blockers)
        package.status = PackageStatus.PUBLISHED
        package.published_at = func.now()
        package.unpublished_at = None
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_PUBLISHED, package)
        return PackageRead.from_model(require_package(self._db, business_id, package_id))

    def _ensure_directly_publishable(self, package: Package, owner_id: UUID) -> None:
        created_by_others = package.promoter_id not in (None, owner_id)
        if package.status == PackageStatus.UNPUBLISHED:
            return
        if package.status == PackageStatus.DRAFT and not created_by_others:
            return
        self._db.rollback()
        if package.status == PackageStatus.DRAFT:
            raise BusinessRuleError(PackageMessages.PUBLISH_REQUIRES_APPROVAL)
        raise BusinessRuleError(PackageMessages.PUBLISH_NOT_AVAILABLE_FOR_STATUS)

    def unpublish(self, business_id: UUID | None, package_id: UUID, actor: User) -> PackageRead:
        package = require_package(self._db, business_id, package_id, for_update=True)
        if package.status == PackageStatus.UNPUBLISHED:
            self._db.rollback()
            return PackageRead.from_model(require_package(self._db, business_id, package_id))
        if package.status != PackageStatus.PUBLISHED:
            self._db.rollback()
            raise BusinessRuleError(PackageMessages.ONLY_PUBLISHED_CAN_BE_UNPUBLISHED)
        package.status = PackageStatus.UNPUBLISHED
        package.unpublished_at = func.now()
        self._db.commit()
        log_package(self._db, actor, PackageAction.PACKAGE_UNPUBLISHED, package)
        return PackageRead.from_model(require_package(self._db, business_id, package_id))
