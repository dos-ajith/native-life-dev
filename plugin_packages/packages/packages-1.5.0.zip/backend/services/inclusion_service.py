from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import User

from ..activity_actions import PackageAction
from ..models import PackageInclusion
from ..schemas.package import InclusionsUpdate, PackageRead
from .package_activity import log_package
from .package_lookup import require_package


class InclusionService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def replace(
        self, business_id: UUID | None, package_id: UUID, payload: InclusionsUpdate, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        package.inclusions = [
            PackageInclusion(
                business_name=item.business_name, provides=item.provides, sort_order=order
            )
            for order, item in enumerate(payload.inclusions)
        ]
        self._db.commit()
        log_package(
            self._db,
            actor,
            PackageAction.INCLUSIONS_UPDATED,
            package,
            {"inclusion_count": len(payload.inclusions)},
        )
        return PackageRead.from_model(require_package(self._db, business_id, package_id))
