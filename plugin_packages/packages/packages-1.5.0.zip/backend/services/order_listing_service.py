from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import Page, PaginationParams, find_order_summaries

from ..repositories.order_link_repository import OrderLinkRepository
from ..schemas.order import PackageOrderRead
from .package_lookup import require_package


class PackageOrderListingService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._links = OrderLinkRepository(db)

    def list_orders(
        self, business_id: UUID | None, package_id: UUID | None, params: PaginationParams
    ) -> Page[PackageOrderRead]:
        if business_id is None:
            return Page[PackageOrderRead].create([], 0, params)
        if package_id is not None:
            require_package(self._db, business_id, package_id)
        rows, total = self._links.list_for_business(
            business_id, package_id, (params.page - 1) * params.page_size, params.page_size
        )
        summaries = find_order_summaries(self._db, business_id, {link.order_id for link, _ in rows})
        return Page[PackageOrderRead].create(
            [
                PackageOrderRead.from_link(link, title, summaries.get(link.order_id))
                for link, title in rows
            ],
            total,
            params,
        )
