from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import AuthorizationError, User, record_activity

from ..activity_actions import PackageAction, PackageEntity
from ..messages import PackageMessages
from ..repositories.business_pricing_repository import BusinessPricingRepository
from ..schemas.package import DefaultPriceRead, DefaultPriceUpdate


class BusinessPricingService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._pricing = BusinessPricingRepository(db)

    def get(self, business_id: UUID) -> DefaultPriceRead:
        pricing = self._pricing.get(business_id)
        return DefaultPriceRead(default_price=pricing.default_price if pricing else None)

    def set(
        self, business_id: UUID, owner_id: UUID, payload: DefaultPriceUpdate, actor: User
    ) -> DefaultPriceRead:
        if owner_id != actor.id:
            raise AuthorizationError(PackageMessages.NOT_BUSINESS_OWNER)
        pricing = self._pricing.set_default_price(business_id, payload.default_price)
        self._db.commit()
        record_activity(
            self._db,
            actor,
            PackageAction.DEFAULT_PRICE_SET,
            PackageEntity.BUSINESS_PRICING,
            business_id,
            {"default_price": str(payload.default_price)},
        )
        return DefaultPriceRead(default_price=pricing.default_price)
