from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import BusinessRuleError, User

from ..activity_actions import PackageAction
from ..messages import PackageMessages
from ..models import Package, PackageVisibility
from ..schemas.package import PackageRead, VisibilityUpdate
from .location_service import require_locations
from .package_activity import log_package
from .package_lookup import require_package


def _sync_visibility(package: Package, wanted: list[UUID]) -> None:
    wanted_set = set(wanted)
    package.visibility = [entry for entry in package.visibility if entry.location_id in wanted_set]
    present = {entry.location_id for entry in package.visibility}
    package.visibility.extend(
        PackageVisibility(location_id=location_id)
        for location_id in wanted
        if location_id not in present
    )


class VisibilityService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def set_visibility(
        self, business_id: UUID | None, package_id: UUID, payload: VisibilityUpdate, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        primary_id = payload.primary_location_id or package.primary_location_id
        if primary_id in payload.location_ids:
            raise BusinessRuleError(PackageMessages.VISIBILITY_INCLUDES_PRIMARY)
        require_locations(
            self._db,
            [
                *payload.location_ids,
                *([payload.primary_location_id] if payload.primary_location_id else []),
            ],
        )
        if payload.primary_location_id is not None:
            package.primary_location_id = payload.primary_location_id
        _sync_visibility(package, payload.location_ids)
        self._db.commit()
        log_package(
            self._db,
            actor,
            PackageAction.VISIBILITY_UPDATED,
            package,
            {"extra_location_count": len(payload.location_ids)},
        )
        return PackageRead.from_model(require_package(self._db, business_id, package_id))
