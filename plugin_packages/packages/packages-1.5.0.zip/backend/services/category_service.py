from collections.abc import Collection
from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import BusinessRuleError, category_slugs_for_businesses

from ..config import RESORT_CATEGORY_SLUG, TRAVEL_CATEGORY_SLUG
from ..messages import PackageMessages
from ..models import PackageCategory
from ..repositories.business_config_repository import BusinessConfigRepository

CATEGORY_BY_SLUG = {
    TRAVEL_CATEGORY_SLUG: PackageCategory.TRAVEL,
    RESORT_CATEGORY_SLUG: PackageCategory.RESORT,
}


def category_from_slugs(slugs: Collection[str]) -> PackageCategory | None:
    return next((CATEGORY_BY_SLUG[slug] for slug in CATEGORY_BY_SLUG if slug in slugs), None)


def business_categories(
    db: Session, business_ids: Collection[UUID]
) -> dict[UUID, PackageCategory | None]:
    slugs = category_slugs_for_businesses(db, business_ids)
    configured = BusinessConfigRepository(db).categories(business_ids)
    result: dict[UUID, PackageCategory | None] = {}
    for business_id in business_ids:
        derived = category_from_slugs(slugs.get(business_id, ()))
        if derived is not None:
            result[business_id] = derived
        elif business_id in configured:
            result[business_id] = PackageCategory(configured[business_id])
        else:
            result[business_id] = None
    return result


def require_business_category(db: Session, business_id: UUID) -> PackageCategory:
    category = business_categories(db, [business_id]).get(business_id)
    if category is None:
        raise BusinessRuleError(PackageMessages.CATEGORY_NOT_CONFIGURED)
    return category
