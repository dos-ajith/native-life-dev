from uuid import UUID

from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.plugins.sdk import (
    BusinessRuleError,
    NotFoundError,
    StoredImage,
    StoredVideo,
    User,
    delete_plugin_image,
    delete_plugin_video,
    save_plugin_image,
    save_plugin_video,
)

from ..activity_actions import PackageAction
from ..config import (
    ALLOWED_IMAGE_TYPES,
    MAX_MEDIA_BYTES,
    MAX_MEDIA_PER_LOCATION,
    MEDIA_PEEK_BYTES,
    MP4_BOX_MARKER,
    MP4_BOX_OFFSET,
    PLUGIN_KEY,
)
from ..messages import PackageMessages
from ..models import MediaKind, Package, PackageCategory, PackageMedia, PackageStatus
from ..repositories.package_repository import PackageRepository
from ..schemas.package import MediaExtras, MediaOrder, PackageRead
from .package_activity import log_package
from .package_lookup import require_package

StoredFile = tuple[MediaKind, StoredImage | StoredVideo]


def _is_video(file: UploadFile) -> bool:
    header = file.file.read(MEDIA_PEEK_BYTES)
    file.file.seek(0)
    return header[MP4_BOX_OFFSET : MP4_BOX_OFFSET + len(MP4_BOX_MARKER)] == MP4_BOX_MARKER


def _store(file: UploadFile, package_id: UUID) -> StoredFile:
    if _is_video(file):
        return MediaKind.VIDEO, save_plugin_video(
            file, PLUGIN_KEY, str(package_id), MAX_MEDIA_BYTES
        )
    image = save_plugin_image(file, PLUGIN_KEY, str(package_id), MAX_MEDIA_BYTES)
    if image.content_type not in ALLOWED_IMAGE_TYPES:
        delete_plugin_image(image.url)
        raise BusinessRuleError(PackageMessages.MEDIA_TYPE_INVALID)
    return MediaKind.IMAGE, image


def _discard(stored: list[StoredFile]) -> None:
    for kind, item in stored:
        (delete_plugin_video if kind == MediaKind.VIDEO else delete_plugin_image)(item.url)


def discard_media_files(media: list[PackageMedia]) -> None:
    for item in media:
        (delete_plugin_video if item.kind == MediaKind.VIDEO else delete_plugin_image)(item.url)


def _target_point_id(package: Package, route_point_id: UUID | None) -> UUID | None:
    points = {point.id for point in package.route_points}
    if route_point_id is None:
        if package.category == PackageCategory.RESORT and len(points) == 1:
            return next(iter(points))
        raise BusinessRuleError(PackageMessages.ROUTE_POINT_REQUIRED)
    if route_point_id not in points:
        raise NotFoundError(PackageMessages.ROUTE_POINT_NOT_FOUND)
    return route_point_id


class PackageMediaService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._packages = PackageRepository(db)

    def upload(
        self,
        business_id: UUID | None,
        package_id: UUID,
        files: list[UploadFile],
        route_point_id: UUID | None,
        actor: User,
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        if not files:
            raise BusinessRuleError(PackageMessages.NO_MEDIA_FILES)
        point_id = _target_point_id(package, route_point_id)
        existing = sum(1 for item in package.media if item.route_point_id == point_id)
        if existing + len(files) > MAX_MEDIA_PER_LOCATION:
            raise BusinessRuleError(
                PackageMessages.TOO_MANY_MEDIA.format(limit=MAX_MEDIA_PER_LOCATION)
            )
        stored: list[StoredFile] = []
        try:
            for file in files:
                stored.append(_store(file, package_id))
            first_order = self._packages.next_media_order(package_id)
            for offset, (kind, item) in enumerate(stored):
                self._packages.add_media(
                    PackageMedia(
                        package_id=package_id,
                        route_point_id=point_id,
                        kind=kind,
                        url=item.url,
                        content_type=item.content_type,
                        size_bytes=item.size_bytes,
                        sort_order=first_order + offset,
                    )
                )
            self._db.commit()
        except Exception:
            self._db.rollback()
            _discard(stored)
            raise
        log_package(
            self._db, actor, PackageAction.MEDIA_ADDED, package, {"media_count": len(stored)}
        )
        return PackageRead.from_model(require_package(self._db, business_id, package_id))

    def remove(
        self, business_id: UUID | None, package_id: UUID, media_id: UUID, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, for_update=True, editable=True)
        media = self._packages.get_media(package_id, media_id)
        if media is None:
            raise NotFoundError(PackageMessages.MEDIA_NOT_FOUND)
        if package.status == PackageStatus.PUBLISHED and len(package.media) <= 1:
            raise BusinessRuleError(PackageMessages.LAST_MEDIA_OF_PUBLISHED)
        url, kind = media.url, media.kind
        self._packages.delete_media(media)
        self._db.commit()
        (delete_plugin_video if kind == MediaKind.VIDEO else delete_plugin_image)(url)
        log_package(
            self._db, actor, PackageAction.MEDIA_REMOVED, package, {"media_id": str(media_id)}
        )
        return PackageRead.from_model(require_package(self._db, business_id, package_id))

    def reorder(
        self, business_id: UUID | None, package_id: UUID, payload: MediaOrder, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        by_id = {item.id: item for item in package.media}
        if (
            len(set(payload.media_ids)) != len(payload.media_ids)
            or set(payload.media_ids) != by_id.keys()
        ):
            raise BusinessRuleError(PackageMessages.MEDIA_ORDER_MISMATCH)
        for order, media_id in enumerate(payload.media_ids):
            by_id[media_id].sort_order = order
        self._db.commit()
        log_package(self._db, actor, PackageAction.MEDIA_REORDERED, package)
        return PackageRead.from_model(require_package(self._db, business_id, package_id))

    def set_extras(
        self, business_id: UUID | None, package_id: UUID, payload: MediaExtras, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        package.youtube_url = payload.youtube_url
        package.extra_content = payload.extra_content
        self._db.commit()
        log_package(self._db, actor, PackageAction.EXTRAS_UPDATED, package)
        return PackageRead.from_model(require_package(self._db, business_id, package_id))
