from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import BusinessRuleError, User

from ..activity_actions import PackageAction
from ..messages import PackageMessages
from ..models import Package, PricingSource
from ..repositories.business_pricing_repository import BusinessPricingRepository
from ..schemas.package import PackageRead, PricingUpdate
from .package_activity import log_package
from .package_lookup import require_package


class PricingService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._business_pricing = BusinessPricingRepository(db)

    def set_pricing(
        self, business_id: UUID | None, package_id: UUID, payload: PricingUpdate, actor: User
    ) -> PackageRead:
        package = require_package(self._db, business_id, package_id, editable=True)
        direct_value = self._direct_value(package, payload)
        if payload.package_price > direct_value:
            raise BusinessRuleError(PackageMessages.PRICE_ABOVE_DIRECT_VALUE)
        package.pricing_source = payload.source
        package.direct_value = direct_value
        package.package_price = payload.package_price
        package.tax_percent = payload.tax_percent
        self._db.commit()
        log_package(
            self._db,
            actor,
            PackageAction.PRICING_UPDATED,
            package,
            {
                "source": str(payload.source),
                "direct_value": str(direct_value),
                "package_price": str(payload.package_price),
                "tax_percent": str(payload.tax_percent),
            },
        )
        return PackageRead.from_model(require_package(self._db, business_id, package_id))

    def _direct_value(self, package: Package, payload: PricingUpdate) -> Decimal:
        if payload.source == PricingSource.MANUAL:
            if payload.direct_value is None:
                raise BusinessRuleError(PackageMessages.DIRECT_VALUE_REQUIRED)
            return payload.direct_value
        if package.business_id is None:
            raise BusinessRuleError(PackageMessages.REQUIRES_BUSINESS)
        pricing = self._business_pricing.get(package.business_id)
        if pricing is None:
            raise BusinessRuleError(PackageMessages.NO_DEFAULT_PRICE)
        return pricing.default_price
