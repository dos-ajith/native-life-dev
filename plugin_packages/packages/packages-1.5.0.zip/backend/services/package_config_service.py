from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import (
    AuthorizationError,
    BusinessRuleError,
    ConflictError,
    User,
    category_slugs_for_businesses,
    record_activity,
)

from ..activity_actions import PackageAction, PackageEntity
from ..messages import PackageMessages
from ..models import PackageCategory
from ..repositories.business_config_repository import BusinessConfigRepository
from ..repositories.package_repository import PackageRepository
from ..schemas.package import PackageCategoryOption, PackageCategoryRead
from .category_service import business_categories, category_from_slugs

BUSINESS_CATEGORY_SOURCE = "business_category"
CONFIGURED_SOURCE = "configured"

CATEGORY_OPTIONS = (
    PackageCategoryOption(
        id=PackageCategory.TRAVEL,
        label="Travel",
        description="Multi-stop tours and trips: pin each destination on the map in order.",
    ),
    PackageCategoryOption(
        id=PackageCategory.RESORT,
        label="Resorts",
        description="Hotels, resorts and stays: pin one destination and show the route to it.",
    ),
)


class PackageConfigService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._config = BusinessConfigRepository(db)
        self._packages = PackageRepository(db)

    def get(self, business_id: UUID) -> PackageCategoryRead:
        category = business_categories(self._db, [business_id]).get(business_id)
        configured = self._config.get(business_id)
        source = None
        if category is not None:
            source = CONFIGURED_SOURCE if configured is not None else BUSINESS_CATEGORY_SOURCE
        return PackageCategoryRead(
            category=category,
            source=source,
            locked=self._packages.has_packages(business_id),
            options=list(CATEGORY_OPTIONS),
        )

    def set(
        self, business_id: UUID, owner_id: UUID, category: PackageCategory, actor: User
    ) -> PackageCategoryRead:
        if owner_id != actor.id:
            raise AuthorizationError(PackageMessages.NOT_BUSINESS_OWNER)
        derived = category_from_slugs(
            category_slugs_for_businesses(self._db, [business_id]).get(business_id, ())
        )
        if derived is not None and derived != category:
            raise BusinessRuleError(
                PackageMessages.CATEGORY_CONFLICTS_WITH_BUSINESS.format(category=derived.value)
            )
        current = self._config.get(business_id)
        changing = current is not None and current.category != category
        if changing and self._packages.has_packages(business_id):
            raise ConflictError(PackageMessages.CATEGORY_LOCKED)
        self._config.set_category(business_id, category)
        self._db.commit()
        record_activity(
            self._db,
            actor,
            PackageAction.CATEGORY_CONFIGURED,
            PackageEntity.BUSINESS_CONFIG,
            business_id,
            {"category": category.value},
        )
        return self.get(business_id)
