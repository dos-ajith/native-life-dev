from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session

from app.plugins.sdk import BookableItem, BookingProvider

from .config import DEFAULT_CURRENCY
from .models import PackageStatus
from .repositories.package_repository import PackageRepository


class PackagesBookingProvider(BookingProvider):
    def find_bookable(self, db: Session, business_id: UUID, item_id: UUID) -> BookableItem | None:
        package = PackageRepository(db).get(business_id, item_id)
        if package is None:
            return None
        return BookableItem(
            id=package.id,
            name=package.title,
            price=package.package_price or Decimal(0),
            currency=DEFAULT_CURRENCY,
            is_active=package.status == PackageStatus.PUBLISHED
            and package.package_price is not None,
            original_price=package.direct_value,
            tax_percent=package.tax_percent,
        )
