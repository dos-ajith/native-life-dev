from collections.abc import Collection
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import BusinessPackageConfig


class BusinessConfigRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get(self, business_id: UUID) -> BusinessPackageConfig | None:
        return self._db.get(BusinessPackageConfig, business_id, populate_existing=True)

    def categories(self, business_ids: Collection[UUID]) -> dict[UUID, str]:
        rows = self._db.scalars(
            select(BusinessPackageConfig).where(BusinessPackageConfig.business_id.in_(business_ids))
        )
        return {row.business_id: row.category for row in rows}

    def set_category(self, business_id: UUID, category: str) -> BusinessPackageConfig:
        config = self.get(business_id)
        if config is None:
            config = BusinessPackageConfig(business_id=business_id, category=category)
            self._db.add(config)
        else:
            config.category = category
        self._db.flush()
        return config
