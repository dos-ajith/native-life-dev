from collections.abc import Collection
from uuid import UUID

from sqlalchemy import ColumnElement, and_, func, or_, select
from sqlalchemy.orm import Session

from ..models import Package, PackageMedia, PackageStatus, PackageVisibility

REFRESH = {"populate_existing": True}


def _business_clause(business_id: UUID | None) -> ColumnElement[bool]:
    if business_id is None:
        return Package.business_id.is_(None)
    return Package.business_id == business_id


class PackageRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get(
        self, business_id: UUID | None, package_id: UUID, for_update: bool = False
    ) -> Package | None:
        statement = (
            select(Package)
            .where(Package.id == package_id, _business_clause(business_id))
            .execution_options(**REFRESH)
        )
        if for_update:
            statement = statement.with_for_update(of=Package)
        return self._db.scalar(statement)

    def get_for_promoter(self, promoter_id: UUID, package_id: UUID) -> Package | None:
        return self._db.scalar(
            select(Package)
            .where(Package.id == package_id, Package.promoter_id == promoter_id)
            .execution_options(**REFRESH)
        )

    def list_for_promoter(
        self, promoter_id: UUID, statuses: Collection[str], offset: int, limit: int
    ) -> tuple[list[Package], int]:
        filters = (Package.promoter_id == promoter_id, Package.status.in_(statuses))
        total = self._db.scalar(select(func.count()).select_from(Package).where(*filters)) or 0
        items = self._db.scalars(
            select(Package)
            .where(*filters)
            .order_by(Package.updated_at.desc(), Package.id)
            .offset(offset)
            .limit(limit)
        ).all()
        return list(items), total

    def list_for_business(
        self,
        business_id: UUID,
        owner_id: UUID,
        statuses: Collection[str],
        offset: int,
        limit: int,
    ) -> tuple[list[Package], int]:
        others_unfinished_draft = and_(
            Package.status == PackageStatus.DRAFT,
            Package.promoter_id.is_not(None),
            Package.promoter_id != owner_id,
        )
        filters = (
            Package.business_id == business_id,
            Package.status.in_(statuses),
            ~others_unfinished_draft,
        )
        total = self._db.scalar(select(func.count()).select_from(Package).where(*filters)) or 0
        items = self._db.scalars(
            select(Package)
            .where(*filters)
            .order_by(Package.updated_at.desc(), Package.id)
            .offset(offset)
            .limit(limit)
        ).all()
        return list(items), total

    def has_packages(self, business_id: UUID) -> bool:
        return (
            self._db.scalar(select(Package.id).where(Package.business_id == business_id).limit(1))
            is not None
        )

    def count_published_by_category(self) -> dict[str, int]:
        rows = self._db.execute(
            select(Package.category, func.count())
            .where(Package.status == PackageStatus.PUBLISHED)
            .group_by(Package.category)
        ).all()
        return {category: count for category, count in rows}

    def get_published(self, package_id: UUID) -> Package | None:
        return self._db.scalar(
            select(Package)
            .where(Package.id == package_id, Package.status == PackageStatus.PUBLISHED)
            .execution_options(**REFRESH)
        )

    def get_many_for_business(
        self, business_id: UUID, package_ids: Collection[UUID]
    ) -> list[Package]:
        return list(
            self._db.scalars(
                select(Package)
                .where(Package.business_id == business_id, Package.id.in_(package_ids))
                .execution_options(**REFRESH)
            )
        )

    def list_published(
        self,
        location_id: UUID | None,
        category: str | None,
        search: str | None,
        offset: int,
        limit: int,
    ) -> tuple[list[Package], int]:
        filters = [Package.status == PackageStatus.PUBLISHED]
        if category is not None:
            filters.append(Package.category == category)
        if location_id is not None:
            shown_there = select(PackageVisibility.package_id).where(
                PackageVisibility.location_id == location_id
            )
            filters.append(
                or_(Package.primary_location_id == location_id, Package.id.in_(shown_there))
            )
        if search:
            filters.append(Package.title.icontains(search, autoescape=True))
        total = self._db.scalar(select(func.count()).select_from(Package).where(*filters)) or 0
        items = self._db.scalars(
            select(Package)
            .where(*filters)
            .order_by(Package.published_at.desc(), Package.id)
            .offset(offset)
            .limit(limit)
        ).all()
        return list(items), total

    def add(self, package: Package) -> Package:
        self._db.add(package)
        self._db.flush()
        return package

    def get_media(self, package_id: UUID, media_id: UUID) -> PackageMedia | None:
        return self._db.scalar(
            select(PackageMedia).where(
                PackageMedia.package_id == package_id, PackageMedia.id == media_id
            )
        )

    def next_media_order(self, package_id: UUID) -> int:
        highest = self._db.scalar(
            select(func.max(PackageMedia.sort_order)).where(PackageMedia.package_id == package_id)
        )
        return 0 if highest is None else highest + 1

    def add_media(self, media: PackageMedia) -> PackageMedia:
        self._db.add(media)
        self._db.flush()
        return media

    def delete_media(self, media: PackageMedia) -> None:
        self._db.delete(media)
        self._db.flush()
