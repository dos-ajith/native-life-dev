from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Package, PackageOrderLink


class OrderLinkRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def list_for_business(
        self, business_id: UUID, package_id: UUID | None, offset: int, limit: int
    ) -> tuple[list[tuple[PackageOrderLink, str]], int]:
        filters = [PackageOrderLink.business_id == business_id]
        if package_id is not None:
            filters.append(PackageOrderLink.package_id == package_id)
        total = (
            self._db.scalar(select(func.count()).select_from(PackageOrderLink).where(*filters)) or 0
        )
        rows = self._db.execute(
            select(PackageOrderLink, Package.title)
            .join(Package, Package.id == PackageOrderLink.package_id)
            .where(*filters)
            .order_by(PackageOrderLink.created_at.desc(), PackageOrderLink.id)
            .offset(offset)
            .limit(limit)
        ).all()
        return [(row[0], row[1]) for row in rows], total
