from collections.abc import Collection
from decimal import Decimal
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import BusinessPricing


class BusinessPricingRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get(self, business_id: UUID) -> BusinessPricing | None:
        return self._db.get(BusinessPricing, business_id, populate_existing=True)

    def default_prices(self, business_ids: Collection[UUID]) -> dict[UUID, Decimal]:
        rows = self._db.scalars(
            select(BusinessPricing).where(BusinessPricing.business_id.in_(business_ids))
        )
        return {row.business_id: row.default_price for row in rows}

    def set_default_price(self, business_id: UUID, default_price: Decimal) -> BusinessPricing:
        pricing = self.get(business_id)
        if pricing is None:
            pricing = BusinessPricing(business_id=business_id, default_price=default_price)
            self._db.add(pricing)
        else:
            pricing.default_price = default_price
        self._db.flush()
        return pricing
