from collections.abc import Collection
from uuid import UUID

from sqlalchemy import func, select, union
from sqlalchemy.orm import Session

from ..models import Location, Package, PackageStatus, PackageVisibility


class LocationRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def list_locations(
        self, search: str | None, offset: int, limit: int
    ) -> tuple[list[Location], int]:
        filters = [Location.name.icontains(search, autoescape=True)] if search else []
        total = self._db.scalar(select(func.count()).select_from(Location).where(*filters)) or 0
        items = self._db.scalars(
            select(Location)
            .where(*filters)
            .order_by(Location.name, Location.id)
            .offset(offset)
            .limit(limit)
        ).all()
        return list(items), total

    def list_with_published_packages(
        self, search: str | None, offset: int, limit: int
    ) -> tuple[list[tuple[Location, int]], int]:
        pairs = union(
            select(
                Package.id.label("package_id"), Package.primary_location_id.label("location_id")
            ).where(
                Package.status == PackageStatus.PUBLISHED, Package.primary_location_id.is_not(None)
            ),
            select(PackageVisibility.package_id, PackageVisibility.location_id)
            .join(Package, Package.id == PackageVisibility.package_id)
            .where(Package.status == PackageStatus.PUBLISHED),
        ).subquery()
        grouped = (
            select(Location, func.count(pairs.c.package_id).label("package_count"))
            .join(pairs, pairs.c.location_id == Location.id)
            .group_by(Location.id)
        )
        if search:
            grouped = grouped.where(Location.name.icontains(search, autoescape=True))
        total = self._db.scalar(select(func.count()).select_from(grouped.subquery())) or 0
        rows = self._db.execute(
            grouped.order_by(Location.name, Location.id).offset(offset).limit(limit)
        ).all()
        return [(row[0], row[1]) for row in rows], total

    def get_many(self, location_ids: Collection[UUID]) -> list[Location]:
        return list(self._db.scalars(select(Location).where(Location.id.in_(location_ids))))

    def get_by_slug(self, slug: str) -> Location | None:
        return self._db.scalar(select(Location).where(Location.slug == slug))

    def add(self, location: Location) -> Location:
        self._db.add(location)
        self._db.flush()
        return location
