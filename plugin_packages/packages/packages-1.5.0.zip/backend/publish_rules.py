from .messages import PackageMessages
from .models import Package, PackageCategory
from .route_rules import points_without_media, route_point_count_valid


def _route_message(category: str) -> str:
    if category == PackageCategory.RESORT:
        return PackageMessages.REQUIRES_RESORT_DESTINATION
    return PackageMessages.REQUIRES_TRAVEL_ROUTE


def publish_blockers(package: Package) -> list[dict[str, str]]:
    uncovered = points_without_media(package)
    blockers: list[tuple[str, str, bool]] = [
        (
            "route_points",
            _route_message(package.category),
            not route_point_count_valid(package.category, len(package.route_points)),
        ),
        ("media", PackageMessages.REQUIRES_MEDIA, not package.media),
        (
            "media",
            PackageMessages.REQUIRES_MEDIA_FOR_LOCATIONS.format(locations=", ".join(uncovered)),
            package.category == PackageCategory.TRAVEL and bool(uncovered) and bool(package.media),
        ),
        ("business", PackageMessages.REQUIRES_BUSINESS, package.business_id is None),
        (
            "pricing",
            PackageMessages.REQUIRES_PRICING,
            package.direct_value is None or package.package_price is None,
        ),
        (
            "pricing",
            PackageMessages.PRICE_ABOVE_DIRECT_VALUE,
            package.direct_value is not None
            and package.package_price is not None
            and package.package_price > package.direct_value,
        ),
        (
            "primary_location",
            PackageMessages.REQUIRES_LOCATION,
            package.primary_location_id is None,
        ),
    ]
    return [
        {"field": field, "message": f"{field}: {message}"}
        for field, message, failed in blockers
        if failed
    ]
