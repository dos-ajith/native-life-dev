from decimal import Decimal
from typing import Annotated, Self
from uuid import UUID

from pydantic import BaseModel, Field, StringConstraints, model_validator

from app.plugins.sdk import BaseReadSchema

from ..config import LATITUDE_LIMIT, LOCATION_NAME_MAX_LENGTH, LONGITUDE_LIMIT
from ..messages import PackageMessages

LocationName = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=LOCATION_NAME_MAX_LENGTH)
]


class LocationCreate(BaseModel):
    name: LocationName
    latitude: Annotated[Decimal | None, Field(ge=-LATITUDE_LIMIT, le=LATITUDE_LIMIT)] = None
    longitude: Annotated[Decimal | None, Field(ge=-LONGITUDE_LIMIT, le=LONGITUDE_LIMIT)] = None

    @model_validator(mode="after")
    def _coordinates_come_together(self) -> Self:
        if (self.latitude is None) != (self.longitude is None):
            raise ValueError(PackageMessages.COORDINATES_INCOMPLETE)
        return self


class LocationRead(BaseReadSchema):
    id: UUID
    name: str
    slug: str
    latitude: Decimal | None
    longitude: Decimal | None


class ExploreLocationRead(LocationRead):
    package_count: int
