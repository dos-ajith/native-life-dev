from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel

from app.plugins.sdk import BaseReadSchema

from ..models import PackageCategory
from .package import PackageInformation


class PromoterPackageCreate(PackageInformation):
    category: PackageCategory


class PromoterBusinessSelection(BaseModel):
    business_id: UUID


class PromoterBusinessRead(BaseReadSchema):
    id: UUID
    name: str
    distance_km: float
    description: str | None
    category: str
    default_price: Decimal | None


class PromoterBusinessesRead(BaseModel):
    has_native_place: bool
    businesses: list[PromoterBusinessRead]
