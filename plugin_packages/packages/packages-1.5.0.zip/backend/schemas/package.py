import enum
from datetime import datetime
from decimal import Decimal
from typing import Annotated, Self
from uuid import UUID

from pydantic import (
    AfterValidator,
    BaseModel,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)

from app.plugins.sdk import BaseReadSchema

from ..config import (
    DESCRIPTION_MAX_LENGTH,
    EXTRA_CONTENT_MAX_LENGTH,
    INCLUSION_TEXT_MAX_LENGTH,
    LATITUDE_LIMIT,
    LONGITUDE_LIMIT,
    MAX_INCLUSIONS,
    MAX_PRICE,
    MAX_ROUTE_POINTS,
    MAX_TAX_PERCENT,
    MAX_VISIBILITY_LOCATIONS,
    REJECTION_NOTE_MAX_LENGTH,
    TITLE_MAX_LENGTH,
    YOUTUBE_URL_MAX_LENGTH,
    YOUTUBE_URL_PATTERN,
)
from ..messages import PackageMessages
from ..models import (
    Package,
    PackageApprovalEvent,
    PackageCategory,
    PackageMedia,
    PricingSource,
    RoutePoint,
)
from ..pricing import amounts
from ..route_rules import cover_url, ordered_media
from ..wizard import completed_steps, next_step
from .location import LocationName, LocationRead

COORDINATE_PRECISION = Decimal("0.000001")

Title = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=TITLE_MAX_LENGTH)
]
Description = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=DESCRIPTION_MAX_LENGTH)
]
InclusionText = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=INCLUSION_TEXT_MAX_LENGTH),
]
Price = Annotated[Decimal, Field(gt=0, le=MAX_PRICE, max_digits=12, decimal_places=2)]
TaxPercent = Annotated[Decimal, Field(ge=0, le=MAX_TAX_PERCENT, max_digits=5, decimal_places=2)]
Latitude = Annotated[
    Decimal,
    Field(ge=-LATITUDE_LIMIT, le=LATITUDE_LIMIT),
    AfterValidator(lambda value: value.quantize(COORDINATE_PRECISION)),
]
Longitude = Annotated[
    Decimal,
    Field(ge=-LONGITUDE_LIMIT, le=LONGITUDE_LIMIT),
    AfterValidator(lambda value: value.quantize(COORDINATE_PRECISION)),
]
RejectionNote = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=REJECTION_NOTE_MAX_LENGTH),
]


class RoutePointInput(BaseModel):
    id: UUID | None = None
    name: LocationName
    latitude: Latitude
    longitude: Longitude


class PackageInformation(BaseModel):
    title: Title
    description: Description
    route_points: Annotated[list[RoutePointInput], Field(min_length=1, max_length=MAX_ROUTE_POINTS)]

    @field_validator("route_points")
    @classmethod
    def _unique_ids(cls, value: list[RoutePointInput]) -> list[RoutePointInput]:
        ids = [point.id for point in value if point.id is not None]
        if len(set(ids)) != len(ids):
            raise ValueError(PackageMessages.ROUTE_POINT_DUPLICATE_ID)
        return value


class MediaExtras(BaseModel):
    youtube_url: Annotated[str | None, Field(max_length=YOUTUBE_URL_MAX_LENGTH)] = None
    extra_content: Annotated[str | None, Field(max_length=EXTRA_CONTENT_MAX_LENGTH)] = None

    @field_validator("youtube_url", "extra_content")
    @classmethod
    def _blank_to_none(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        return value.strip()

    @field_validator("youtube_url")
    @classmethod
    def _must_be_youtube(cls, value: str | None) -> str | None:
        if value is not None and YOUTUBE_URL_PATTERN.match(value) is None:
            raise ValueError(PackageMessages.YOUTUBE_URL_INVALID)
        return value


class MediaOrder(BaseModel):
    media_ids: Annotated[list[UUID], Field(min_length=1)]


class InclusionInput(BaseModel):
    business_name: InclusionText
    provides: InclusionText


class InclusionsUpdate(BaseModel):
    inclusions: Annotated[list[InclusionInput], Field(min_length=1, max_length=MAX_INCLUSIONS)]


class PricingUpdate(BaseModel):
    source: PricingSource = PricingSource.MANUAL
    direct_value: Price | None = None
    package_price: Price
    tax_percent: TaxPercent = Decimal(0)

    @model_validator(mode="after")
    def _price_within_direct_value(self) -> Self:
        if self.source == PricingSource.MANUAL and self.direct_value is None:
            raise ValueError(PackageMessages.DIRECT_VALUE_REQUIRED)
        if self.direct_value is not None and self.package_price > self.direct_value:
            raise ValueError(PackageMessages.PRICE_ABOVE_DIRECT_VALUE)
        return self


class PackageCategoryUpdate(BaseModel):
    category: PackageCategory


class PackageCategoryOption(BaseModel):
    id: PackageCategory
    label: str
    description: str


class PackageCategoryRead(BaseModel):
    category: PackageCategory | None
    source: str | None
    locked: bool
    options: list[PackageCategoryOption]


class DefaultPriceUpdate(BaseModel):
    default_price: Price


class DefaultPriceRead(BaseModel):
    default_price: Decimal | None


class RejectionInput(BaseModel):
    note: RejectionNote


class VisibilityUpdate(BaseModel):
    primary_location_id: UUID | None = None
    location_ids: Annotated[list[UUID], Field(max_length=MAX_VISIBILITY_LOCATIONS)] = []

    @field_validator("location_ids")
    @classmethod
    def _no_duplicates(cls, value: list[UUID]) -> list[UUID]:
        if len(set(value)) != len(value):
            raise ValueError(PackageMessages.DUPLICATE_LOCATIONS)
        return value


class MediaRead(BaseReadSchema):
    id: UUID
    route_point_id: UUID | None
    kind: str
    url: str
    content_type: str
    size_bytes: int
    sort_order: int

    @classmethod
    def from_model(cls, item: PackageMedia) -> Self:
        return cls.model_validate(item)


class RoutePointRead(BaseReadSchema):
    id: UUID
    sequence: int
    name: str
    latitude: Decimal
    longitude: Decimal
    media: list[MediaRead]

    @classmethod
    def list_from_package(cls, package: Package) -> list[Self]:
        media_by_point: dict[UUID | None, list[MediaRead]] = {}
        for item in ordered_media(package):
            media_by_point.setdefault(item.route_point_id, []).append(MediaRead.from_model(item))
        return [
            cls._build(point, media_by_point.get(point.id, [])) for point in package.route_points
        ]

    @classmethod
    def _build(cls, point: RoutePoint, media: list[MediaRead]) -> Self:
        return cls(
            id=point.id,
            sequence=point.sequence,
            name=point.name,
            latitude=point.latitude,
            longitude=point.longitude,
            media=media,
        )


class OriginRead(BaseReadSchema):
    name: str
    latitude: Decimal
    longitude: Decimal

    @classmethod
    def from_package(cls, package: Package) -> Self | None:
        if (
            package.origin_name is None
            or package.origin_latitude is None
            or package.origin_longitude is None
        ):
            return None
        return cls(
            name=package.origin_name,
            latitude=package.origin_latitude,
            longitude=package.origin_longitude,
        )


class ApprovalEventRead(BaseReadSchema):
    id: UUID
    action: str
    actor_id: UUID | None
    note: str | None
    created_at: datetime

    @classmethod
    def from_model(cls, event: PackageApprovalEvent) -> Self:
        return cls.model_validate(event)


class InclusionRead(BaseReadSchema):
    id: UUID
    business_name: str
    provides: str
    sort_order: int


def _primary_location(package: Package) -> LocationRead | None:
    if package.primary_location is None:
        return None
    return LocationRead.model_validate(package.primary_location)


def _visibility(package: Package) -> list[LocationRead]:
    return [LocationRead.model_validate(entry.location) for entry in package.visibility]


def _rejection_note(package: Package) -> str | None:
    if package.status != "rejected":
        return None
    rejections = [event for event in package.approval_events if event.action == "rejected"]
    return rejections[-1].note if rejections else None


class PackageRead(BaseReadSchema):
    id: UUID
    business_id: UUID | None
    business_name: str | None = None
    promoter_id: UUID | None
    category: str
    status: str
    title: str
    description: str
    route_points: list[RoutePointRead]
    origin: OriginRead | None
    primary_location: LocationRead | None
    media: list[MediaRead]
    cover_url: str | None
    youtube_url: str | None
    extra_content: str | None
    inclusions: list[InclusionRead]
    pricing_source: str | None
    business_default_price: Decimal | None
    direct_value: Decimal | None
    package_price: Decimal | None
    tax_percent: Decimal
    saving: Decimal | None
    discount_percent: Decimal | None
    visibility_locations: list[LocationRead]
    approval_history: list[ApprovalEventRead]
    rejection_note: str | None
    completed_steps: list[int]
    next_step: int
    published_at: datetime | None
    unpublished_at: datetime | None
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_model(cls, package: Package) -> Self:
        saving, discount_percent = amounts(package.direct_value, package.package_price)
        return cls(
            id=package.id,
            business_id=package.business_id,
            promoter_id=package.promoter_id,
            category=package.category,
            status=package.status,
            title=package.title,
            description=package.description,
            route_points=RoutePointRead.list_from_package(package),
            origin=OriginRead.from_package(package),
            primary_location=_primary_location(package),
            media=[MediaRead.from_model(item) for item in ordered_media(package)],
            cover_url=cover_url(package),
            youtube_url=package.youtube_url,
            extra_content=package.extra_content,
            inclusions=[InclusionRead.model_validate(item) for item in package.inclusions],
            pricing_source=package.pricing_source,
            business_default_price=(
                package.business_pricing.default_price
                if package.business_pricing is not None
                else None
            ),
            direct_value=package.direct_value,
            package_price=package.package_price,
            tax_percent=package.tax_percent,
            saving=saving,
            discount_percent=discount_percent,
            visibility_locations=_visibility(package),
            approval_history=[ApprovalEventRead.from_model(e) for e in package.approval_events],
            rejection_note=_rejection_note(package),
            completed_steps=completed_steps(package),
            next_step=next_step(package),
            published_at=package.published_at,
            unpublished_at=package.unpublished_at,
            created_at=package.created_at,
            updated_at=package.updated_at,
        )


class PackageTab(enum.StrEnum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"


class PackageSummary(BaseReadSchema):
    id: UUID
    business_id: UUID | None
    promoter_id: UUID | None
    category: str
    status: str
    title: str
    cover_url: str | None
    primary_location: LocationRead | None
    destination_names: list[str]
    direct_value: Decimal | None
    package_price: Decimal | None
    discount_percent: Decimal | None
    next_step: int
    published_at: datetime | None
    updated_at: datetime

    @classmethod
    def from_model(cls, package: Package) -> Self:
        _, percent = amounts(package.direct_value, package.package_price)
        return cls(
            id=package.id,
            business_id=package.business_id,
            promoter_id=package.promoter_id,
            category=package.category,
            status=package.status,
            title=package.title,
            cover_url=cover_url(package),
            primary_location=_primary_location(package),
            destination_names=[point.name for point in package.route_points],
            direct_value=package.direct_value,
            package_price=package.package_price,
            discount_percent=percent,
            next_step=next_step(package),
            published_at=package.published_at,
            updated_at=package.updated_at,
        )


class PackageDetail(BaseReadSchema):
    id: UUID
    business_id: UUID | None
    business_name: str | None = None
    category: str
    title: str
    description: str
    route_points: list[RoutePointRead]
    origin: OriginRead | None
    primary_location: LocationRead | None
    media: list[MediaRead]
    cover_url: str | None
    youtube_url: str | None
    extra_content: str | None
    inclusions: list[InclusionRead]
    direct_value: Decimal | None
    package_price: Decimal | None
    tax_percent: Decimal
    saving: Decimal | None
    discount_percent: Decimal | None
    visibility_locations: list[LocationRead]
    published_at: datetime | None

    @classmethod
    def from_model(cls, package: Package) -> Self:
        saving, discount_percent = amounts(package.direct_value, package.package_price)
        return cls(
            id=package.id,
            business_id=package.business_id,
            category=package.category,
            title=package.title,
            description=package.description,
            route_points=RoutePointRead.list_from_package(package),
            origin=OriginRead.from_package(package),
            primary_location=_primary_location(package),
            media=[MediaRead.from_model(item) for item in ordered_media(package)],
            cover_url=cover_url(package),
            youtube_url=package.youtube_url,
            extra_content=package.extra_content,
            inclusions=[InclusionRead.model_validate(item) for item in package.inclusions],
            direct_value=package.direct_value,
            package_price=package.package_price,
            tax_percent=package.tax_percent,
            saving=saving,
            discount_percent=discount_percent,
            visibility_locations=_visibility(package),
            published_at=package.published_at,
        )


class ExploreCategoryRead(BaseReadSchema):
    id: PackageCategory
    name: str
    package_count: int


class ExplorePackageSummary(BaseReadSchema):
    id: UUID
    business_id: UUID | None
    category: str
    title: str
    description: str
    cover_url: str | None
    primary_location: LocationRead | None
    destination_names: list[str]
    direct_value: Decimal
    package_price: Decimal
    tax_percent: Decimal
    saving: Decimal
    discount_percent: Decimal
    published_at: datetime | None

    @classmethod
    def from_model(cls, package: Package) -> Self:
        direct_value = package.direct_value or Decimal(0)
        package_price = package.package_price or Decimal(0)
        saving, discount_percent = amounts(direct_value, package_price)
        return cls(
            id=package.id,
            business_id=package.business_id,
            category=package.category,
            title=package.title,
            description=package.description,
            cover_url=cover_url(package),
            primary_location=_primary_location(package),
            destination_names=[point.name for point in package.route_points],
            direct_value=direct_value,
            package_price=package_price,
            tax_percent=package.tax_percent,
            saving=saving or Decimal(0),
            discount_percent=discount_percent or Decimal(0),
            published_at=package.published_at,
        )
