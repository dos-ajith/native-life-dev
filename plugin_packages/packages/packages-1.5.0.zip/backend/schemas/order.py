from datetime import datetime
from decimal import Decimal
from uuid import UUID

from app.plugins.sdk import BaseReadSchema, OrderSummary

from ..models import PackageOrderLink


class PackageOrderRead(BaseReadSchema):
    order_id: UUID
    order_number: str | None
    status: str | None
    customer_name: str | None
    package_id: UUID
    package_title: str
    quantity: int
    direct_value: Decimal
    package_price: Decimal
    line_total: Decimal
    order_total: Decimal | None
    currency: str | None
    placed_at: datetime

    @classmethod
    def from_link(
        cls, link: PackageOrderLink, package_title: str, order: OrderSummary | None
    ) -> "PackageOrderRead":
        return cls(
            order_id=link.order_id,
            order_number=order.order_number if order else None,
            status=order.status if order else None,
            customer_name=order.customer_name if order else None,
            package_id=link.package_id,
            package_title=package_title,
            quantity=link.quantity,
            direct_value=link.direct_value,
            package_price=link.package_price,
            line_total=link.package_price * link.quantity,
            order_total=order.total_amount if order else None,
            currency=order.currency if order else None,
            placed_at=order.created_at if order else link.created_at,
        )
