class PackagePermission:
    PACKAGES_VIEW = "plugin.packages.packages.view"
    PACKAGES_MANAGE = "plugin.packages.packages.manage"
    ORDERS_VIEW = "plugin.packages.orders.view"
