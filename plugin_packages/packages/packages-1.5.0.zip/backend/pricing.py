from decimal import Decimal

from .config import PERCENT, PERCENT_PRECISION


def saving(direct_value: Decimal, package_price: Decimal) -> Decimal:
    return direct_value - package_price


def amounts(
    direct_value: Decimal | None, package_price: Decimal | None
) -> tuple[Decimal | None, Decimal | None]:
    if direct_value is None or package_price is None:
        return None, None
    return saving(direct_value, package_price), discount_percent(direct_value, package_price)


def discount_percent(direct_value: Decimal, package_price: Decimal) -> Decimal:
    if direct_value <= 0 or package_price >= direct_value:
        return Decimal(0)
    return ((direct_value - package_price) / direct_value * PERCENT).quantize(PERCENT_PRECISION)
