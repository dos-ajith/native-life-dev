from typing import Annotated

from fastapi import APIRouter, Query

from app.plugins.sdk import DbSessionDep, Page, PaginationDep, SuccessResponse

from ..messages import PackageMessages
from ..schemas.location import LocationCreate, LocationRead
from ..services.location_service import LocationService
from .dependencies import BusinessDep, PackageManagerDep, PackageViewerDep

CREATED = 201
SEARCH_MAX_LENGTH = 100

router = APIRouter()


@router.get(
    "/businesses/{business_id}/package-locations",
    response_model=SuccessResponse[Page[LocationRead]],
)
def list_locations(
    _: PackageViewerDep,
    business: BusinessDep,
    db: DbSessionDep,
    params: PaginationDep,
    q: Annotated[str | None, Query(max_length=SEARCH_MAX_LENGTH)] = None,
) -> SuccessResponse[Page[LocationRead]]:
    return SuccessResponse(
        message=PackageMessages.LOCATIONS_RETRIEVED,
        data=LocationService(db).list_page(params, q),
    )


@router.post(
    "/businesses/{business_id}/package-locations",
    response_model=SuccessResponse[LocationRead],
    status_code=CREATED,
)
def create_location(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    payload: LocationCreate,
) -> SuccessResponse[LocationRead]:
    return SuccessResponse(
        message=PackageMessages.LOCATION_CREATED,
        data=LocationService(db).create(payload, actor),
    )
