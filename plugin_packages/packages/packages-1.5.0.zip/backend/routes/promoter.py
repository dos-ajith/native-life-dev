from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Query, UploadFile

from app.plugins.sdk import DbSessionDep, Page, PaginationDep, SuccessResponse

from ..messages import PackageMessages
from ..models import PackageCategory
from ..schemas.location import LocationCreate, LocationRead
from ..schemas.order import PackageOrderRead
from ..schemas.package import (
    InclusionsUpdate,
    MediaExtras,
    MediaOrder,
    PackageDetail,
    PackageInformation,
    PackageRead,
    PackageSummary,
    PackageTab,
    PricingUpdate,
    VisibilityUpdate,
)
from ..schemas.promoter import (
    PromoterBusinessesRead,
    PromoterBusinessSelection,
    PromoterPackageCreate,
)
from ..services.approval_service import PackageApprovalService
from ..services.inclusion_service import InclusionService
from ..services.location_service import LocationService
from ..services.media_service import PackageMediaService
from ..services.order_listing_service import PackageOrderListingService
from ..services.package_lookup import require_own_editable_package, require_own_package
from ..services.package_service import PackageService
from ..services.pricing_service import PricingService
from ..services.promoter_service import PromoterPackageService
from ..services.publishing_service import PublishingService
from ..services.visibility_service import VisibilityService
from .dependencies import (
    OrderViewerDep,
    PackageManagerDep,
    PackageViewerDep,
    require_promoter_role,
)

CREATED = 201
SEARCH_MAX_LENGTH = 100

router = APIRouter(prefix="/promoter", dependencies=[Depends(require_promoter_role)])


@router.get("/businesses", response_model=SuccessResponse[PromoterBusinessesRead])
def list_available_businesses(
    actor: PackageViewerDep, db: DbSessionDep, category: PackageCategory | None = None
) -> SuccessResponse[PromoterBusinessesRead]:
    return SuccessResponse(
        message=PackageMessages.PROMOTER_BUSINESSES_RETRIEVED,
        data=PromoterPackageService(db).available_businesses(actor, category),
    )


@router.get("/package-locations", response_model=SuccessResponse[Page[LocationRead]])
def list_locations(
    _: PackageViewerDep,
    db: DbSessionDep,
    params: PaginationDep,
    q: Annotated[str | None, Query(max_length=SEARCH_MAX_LENGTH)] = None,
) -> SuccessResponse[Page[LocationRead]]:
    return SuccessResponse(
        message=PackageMessages.LOCATIONS_RETRIEVED, data=LocationService(db).list_page(params, q)
    )


@router.post(
    "/package-locations", response_model=SuccessResponse[LocationRead], status_code=CREATED
)
def create_location(
    actor: PackageManagerDep, db: DbSessionDep, payload: LocationCreate
) -> SuccessResponse[LocationRead]:
    return SuccessResponse(
        message=PackageMessages.LOCATION_CREATED, data=LocationService(db).create(payload, actor)
    )


@router.get("/packages", response_model=SuccessResponse[Page[PackageSummary]])
def list_packages(
    actor: PackageViewerDep,
    db: DbSessionDep,
    params: PaginationDep,
    tab: PackageTab = PackageTab.ACTIVE,
) -> SuccessResponse[Page[PackageSummary]]:
    return SuccessResponse(
        message=PackageMessages.PACKAGES_RETRIEVED,
        data=PromoterPackageService(db).list_page(actor, tab, params),
    )


@router.post("/packages", response_model=SuccessResponse[PackageRead], status_code=CREATED)
def create_package(
    actor: PackageManagerDep, db: DbSessionDep, payload: PromoterPackageCreate
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_CREATED,
        data=PromoterPackageService(db).create_draft(actor, payload),
    )


@router.get("/packages/{package_id}", response_model=SuccessResponse[PackageRead])
def get_package(
    actor: PackageViewerDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageRead]:
    package = require_own_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.PACKAGE_RETRIEVED,
        data=PackageService(db).get(package.business_id, package_id),
    )


@router.put("/packages/{package_id}/information", response_model=SuccessResponse[PackageRead])
def update_information(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: PackageInformation
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.INFORMATION_UPDATED,
        data=PackageService(db).update_information(package.business_id, package_id, payload, actor),
    )


@router.put("/packages/{package_id}/inclusions", response_model=SuccessResponse[PackageRead])
def update_inclusions(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: InclusionsUpdate
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.INCLUSIONS_UPDATED,
        data=InclusionService(db).replace(package.business_id, package_id, payload, actor),
    )


@router.put("/packages/{package_id}/pricing", response_model=SuccessResponse[PackageRead])
def update_pricing(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: PricingUpdate
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.PRICING_UPDATED,
        data=PricingService(db).set_pricing(package.business_id, package_id, payload, actor),
    )


@router.put("/packages/{package_id}/visibility", response_model=SuccessResponse[PackageRead])
def update_visibility(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: VisibilityUpdate
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.VISIBILITY_UPDATED,
        data=VisibilityService(db).set_visibility(package.business_id, package_id, payload, actor),
    )


@router.post(
    "/packages/{package_id}/media",
    response_model=SuccessResponse[PackageRead],
    status_code=CREATED,
)
def upload_media(
    actor: PackageManagerDep,
    db: DbSessionDep,
    package_id: UUID,
    files: Annotated[list[UploadFile], File()],
    route_point_id: Annotated[UUID | None, Form()] = None,
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.MEDIA_ADDED,
        data=PackageMediaService(db).upload(
            package.business_id, package_id, files, route_point_id, actor
        ),
    )


@router.put("/packages/{package_id}/media/order", response_model=SuccessResponse[PackageRead])
def reorder_media(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: MediaOrder
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.MEDIA_REORDERED,
        data=PackageMediaService(db).reorder(package.business_id, package_id, payload, actor),
    )


@router.delete(
    "/packages/{package_id}/media/{media_id}", response_model=SuccessResponse[PackageRead]
)
def remove_media(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, media_id: UUID
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.MEDIA_REMOVED,
        data=PackageMediaService(db).remove(package.business_id, package_id, media_id, actor),
    )


@router.put("/packages/{package_id}/extras", response_model=SuccessResponse[PackageRead])
def update_extras(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: MediaExtras
) -> SuccessResponse[PackageRead]:
    package = require_own_editable_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.EXTRAS_UPDATED,
        data=PackageMediaService(db).set_extras(package.business_id, package_id, payload, actor),
    )


@router.get("/packages/{package_id}/preview", response_model=SuccessResponse[PackageDetail])
def preview_package(
    actor: PackageViewerDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageDetail]:
    package = require_own_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.PREVIEW_RETRIEVED,
        data=PackageService(db).preview(package.business_id, package_id),
    )


@router.put("/packages/{package_id}/business", response_model=SuccessResponse[PackageRead])
def select_business(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID, payload: PromoterBusinessSelection
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.BUSINESS_SELECTED,
        data=PromoterPackageService(db).select_business(actor, package_id, payload.business_id),
    )


@router.post("/packages/{package_id}/submit", response_model=SuccessResponse[PackageRead])
def submit_package(
    actor: PackageManagerDep,
    db: DbSessionDep,
    background_tasks: BackgroundTasks,
    package_id: UUID,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.SUBMITTED_FOR_APPROVAL,
        data=PackageApprovalService(db, background_tasks).submit(actor, package_id),
    )


@router.post("/packages/{package_id}/unpublish", response_model=SuccessResponse[PackageRead])
def unpublish_package(
    actor: PackageManagerDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageRead]:
    package = require_own_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.PACKAGE_UNPUBLISHED,
        data=PublishingService(db).unpublish(package.business_id, package_id, actor),
    )


@router.get("/packages/{package_id}/orders", response_model=SuccessResponse[Page[PackageOrderRead]])
def list_package_orders(
    actor: OrderViewerDep, db: DbSessionDep, package_id: UUID, params: PaginationDep
) -> SuccessResponse[Page[PackageOrderRead]]:
    package = require_own_package(db, actor.id, package_id)
    return SuccessResponse(
        message=PackageMessages.ORDERS_RETRIEVED,
        data=PackageOrderListingService(db).list_orders(package.business_id, package_id, params),
    )
