from typing import Annotated

from fastapi import Depends

from app.plugins.sdk import (
    AuthorizationError,
    CurrentActiveUserDep,
    PluginBusiness,
    User,
    require_business_plugin,
    require_permission,
)

from ..config import PLUGIN_KEY, PROMOTER_ROLE_SLUG
from ..messages import PackageMessages
from ..permissions import PackagePermission

business_access = require_business_plugin(PLUGIN_KEY)
BusinessDep = Annotated[PluginBusiness, Depends(business_access)]
PackageViewerDep = Annotated[User, Depends(require_permission(PackagePermission.PACKAGES_VIEW))]
OrderViewerDep = Annotated[User, Depends(require_permission(PackagePermission.ORDERS_VIEW))]
PackageManagerDep = Annotated[User, Depends(require_permission(PackagePermission.PACKAGES_MANAGE))]


def require_promoter_role(user: CurrentActiveUserDep) -> None:
    if not any(role.slug == PROMOTER_ROLE_SLUG for role in user.roles):
        raise AuthorizationError(PackageMessages.PROMOTER_ONLY)
