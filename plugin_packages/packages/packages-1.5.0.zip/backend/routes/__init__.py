from fastapi import APIRouter

from .explore import router as explore_router
from .locations import router as locations_router
from .package_media import router as package_media_router
from .package_orders import router as package_orders_router
from .packages import router as packages_router
from .promoter import router as promoter_router

ROUTERS: tuple[APIRouter, ...] = (
    explore_router,
    locations_router,
    packages_router,
    package_media_router,
    package_orders_router,
    promoter_router,
)
