from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, File, Form, UploadFile

from app.plugins.sdk import DbSessionDep, SuccessResponse

from ..messages import PackageMessages
from ..schemas.package import MediaExtras, MediaOrder, PackageRead
from ..services.media_service import PackageMediaService
from .dependencies import BusinessDep, PackageManagerDep

CREATED = 201

router = APIRouter()


@router.post(
    "/businesses/{business_id}/packages/{package_id}/media",
    response_model=SuccessResponse[PackageRead],
    status_code=CREATED,
)
def upload_media(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    files: Annotated[list[UploadFile], File()],
    route_point_id: Annotated[UUID | None, Form()] = None,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.MEDIA_ADDED,
        data=PackageMediaService(db).upload(business.id, package_id, files, route_point_id, actor),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/media/order",
    response_model=SuccessResponse[PackageRead],
)
def reorder_media(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: MediaOrder,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.MEDIA_REORDERED,
        data=PackageMediaService(db).reorder(business.id, package_id, payload, actor),
    )


@router.delete(
    "/businesses/{business_id}/packages/{package_id}/media/{media_id}",
    response_model=SuccessResponse[PackageRead],
)
def remove_media(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    media_id: UUID,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.MEDIA_REMOVED,
        data=PackageMediaService(db).remove(business.id, package_id, media_id, actor),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/extras",
    response_model=SuccessResponse[PackageRead],
)
def update_extras(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: MediaExtras,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.EXTRAS_UPDATED,
        data=PackageMediaService(db).set_extras(business.id, package_id, payload, actor),
    )
