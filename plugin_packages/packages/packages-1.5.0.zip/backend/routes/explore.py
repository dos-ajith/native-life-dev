from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from app.plugins.sdk import CurrentActiveUserDep, DbSessionDep, Page, PaginationDep, SuccessResponse

from ..messages import PackageMessages
from ..models import PackageCategory
from ..schemas.location import ExploreLocationRead
from ..schemas.package import ExploreCategoryRead, ExplorePackageSummary, PackageDetail
from ..services.explore_service import ExploreService

SEARCH_MAX_LENGTH = 100

router = APIRouter(prefix="/explore")


@router.get("/categories", response_model=SuccessResponse[list[ExploreCategoryRead]])
def explore_categories(
    _: CurrentActiveUserDep, db: DbSessionDep
) -> SuccessResponse[list[ExploreCategoryRead]]:
    return SuccessResponse(
        message=PackageMessages.EXPLORE_CATEGORIES_RETRIEVED,
        data=ExploreService(db).list_categories(),
    )


@router.get("/locations", response_model=SuccessResponse[Page[ExploreLocationRead]])
def explore_locations(
    _: CurrentActiveUserDep,
    db: DbSessionDep,
    params: PaginationDep,
    q: Annotated[str | None, Query(max_length=SEARCH_MAX_LENGTH)] = None,
) -> SuccessResponse[Page[ExploreLocationRead]]:
    return SuccessResponse(
        message=PackageMessages.EXPLORE_LOCATIONS_RETRIEVED,
        data=ExploreService(db).list_locations(params, q),
    )


@router.get("/packages", response_model=SuccessResponse[Page[ExplorePackageSummary]])
def explore_packages(
    _: CurrentActiveUserDep,
    db: DbSessionDep,
    params: PaginationDep,
    location_id: UUID | None = None,
    category: PackageCategory | None = None,
    q: Annotated[str | None, Query(max_length=SEARCH_MAX_LENGTH)] = None,
) -> SuccessResponse[Page[ExplorePackageSummary]]:
    return SuccessResponse(
        message=PackageMessages.EXPLORE_PACKAGES_RETRIEVED,
        data=ExploreService(db).list_packages(params, location_id, category, q),
    )


@router.get("/packages/{package_id}", response_model=SuccessResponse[PackageDetail])
def get_explore_package(
    package_id: UUID, _: CurrentActiveUserDep, db: DbSessionDep
) -> SuccessResponse[PackageDetail]:
    return SuccessResponse(
        message=PackageMessages.EXPLORE_PACKAGE_RETRIEVED,
        data=ExploreService(db).get(package_id),
    )
