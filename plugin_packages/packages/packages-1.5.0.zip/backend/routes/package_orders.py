from uuid import UUID

from fastapi import APIRouter

from app.plugins.sdk import DbSessionDep, Page, PaginationDep, SuccessResponse

from ..messages import PackageMessages
from ..schemas.order import PackageOrderRead
from ..services.order_listing_service import PackageOrderListingService
from .dependencies import BusinessDep, OrderViewerDep

router = APIRouter()


@router.get(
    "/businesses/{business_id}/package-orders",
    response_model=SuccessResponse[Page[PackageOrderRead]],
)
def list_business_package_orders(
    _: OrderViewerDep, business: BusinessDep, db: DbSessionDep, params: PaginationDep
) -> SuccessResponse[Page[PackageOrderRead]]:
    return SuccessResponse(
        message=PackageMessages.ORDERS_RETRIEVED,
        data=PackageOrderListingService(db).list_orders(business.id, None, params),
    )


@router.get(
    "/businesses/{business_id}/packages/{package_id}/orders",
    response_model=SuccessResponse[Page[PackageOrderRead]],
)
def list_package_orders(
    _: OrderViewerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    params: PaginationDep,
) -> SuccessResponse[Page[PackageOrderRead]]:
    return SuccessResponse(
        message=PackageMessages.ORDERS_RETRIEVED,
        data=PackageOrderListingService(db).list_orders(business.id, package_id, params),
    )
