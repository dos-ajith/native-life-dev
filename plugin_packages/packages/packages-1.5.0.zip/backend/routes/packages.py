from uuid import UUID

from fastapi import APIRouter, BackgroundTasks

from app.plugins.sdk import DbSessionDep, Page, PaginationDep, SuccessResponse

from ..messages import PackageMessages
from ..schemas.package import (
    DefaultPriceRead,
    DefaultPriceUpdate,
    InclusionsUpdate,
    PackageCategoryRead,
    PackageCategoryUpdate,
    PackageDetail,
    PackageInformation,
    PackageRead,
    PackageSummary,
    PackageTab,
    PricingUpdate,
    RejectionInput,
    VisibilityUpdate,
)
from ..services.approval_service import PackageApprovalService
from ..services.business_pricing_service import BusinessPricingService
from ..services.inclusion_service import InclusionService
from ..services.package_config_service import PackageConfigService
from ..services.package_service import PackageService
from ..services.pricing_service import PricingService
from ..services.publishing_service import PublishingService
from ..services.visibility_service import VisibilityService
from .dependencies import BusinessDep, PackageManagerDep, PackageViewerDep

CREATED = 201

router = APIRouter()


@router.post(
    "/businesses/{business_id}/packages",
    response_model=SuccessResponse[PackageRead],
    status_code=CREATED,
)
def create_package(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    payload: PackageInformation,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_CREATED,
        data=PackageService(db).create_for_business(business.id, business.owner_id, payload, actor),
    )


@router.get(
    "/businesses/{business_id}/packages",
    response_model=SuccessResponse[Page[PackageSummary]],
)
def list_packages(
    _: PackageViewerDep,
    business: BusinessDep,
    db: DbSessionDep,
    params: PaginationDep,
    tab: PackageTab = PackageTab.ACTIVE,
) -> SuccessResponse[Page[PackageSummary]]:
    return SuccessResponse(
        message=PackageMessages.PACKAGES_RETRIEVED,
        data=PackageService(db).list_page(business.id, business.owner_id, tab, params),
    )


@router.get(
    "/businesses/{business_id}/packages/{package_id}",
    response_model=SuccessResponse[PackageRead],
)
def get_package(
    _: PackageViewerDep, business: BusinessDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_RETRIEVED,
        data=PackageService(db).get(business.id, package_id),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/information",
    response_model=SuccessResponse[PackageRead],
)
def update_information(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: PackageInformation,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.INFORMATION_UPDATED,
        data=PackageService(db).update_information(business.id, package_id, payload, actor),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/inclusions",
    response_model=SuccessResponse[PackageRead],
)
def update_inclusions(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: InclusionsUpdate,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.INCLUSIONS_UPDATED,
        data=InclusionService(db).replace(business.id, package_id, payload, actor),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/pricing",
    response_model=SuccessResponse[PackageRead],
)
def update_pricing(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: PricingUpdate,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PRICING_UPDATED,
        data=PricingService(db).set_pricing(business.id, package_id, payload, actor),
    )


@router.put(
    "/businesses/{business_id}/packages/{package_id}/visibility",
    response_model=SuccessResponse[PackageRead],
)
def update_visibility(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    package_id: UUID,
    payload: VisibilityUpdate,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.VISIBILITY_UPDATED,
        data=VisibilityService(db).set_visibility(business.id, package_id, payload, actor),
    )


@router.get(
    "/businesses/{business_id}/packages/{package_id}/preview",
    response_model=SuccessResponse[PackageDetail],
)
def preview_package(
    _: PackageViewerDep, business: BusinessDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageDetail]:
    return SuccessResponse(
        message=PackageMessages.PREVIEW_RETRIEVED,
        data=PackageService(db).preview(business.id, package_id),
    )


@router.post(
    "/businesses/{business_id}/packages/{package_id}/publish",
    response_model=SuccessResponse[PackageRead],
)
def publish_package(
    actor: PackageManagerDep, business: BusinessDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_PUBLISHED,
        data=PublishingService(db).publish(business.id, business.owner_id, package_id, actor),
    )


@router.post(
    "/businesses/{business_id}/packages/{package_id}/unpublish",
    response_model=SuccessResponse[PackageRead],
)
def unpublish_package(
    actor: PackageManagerDep, business: BusinessDep, db: DbSessionDep, package_id: UUID
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_UNPUBLISHED,
        data=PublishingService(db).unpublish(business.id, package_id, actor),
    )


@router.post(
    "/businesses/{business_id}/packages/{package_id}/approve",
    response_model=SuccessResponse[PackageRead],
)
def approve_package(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    background_tasks: BackgroundTasks,
    package_id: UUID,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_APPROVED,
        data=PackageApprovalService(db, background_tasks).approve(business, package_id, actor),
    )


@router.post(
    "/businesses/{business_id}/packages/{package_id}/reject",
    response_model=SuccessResponse[PackageRead],
)
def reject_package(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    background_tasks: BackgroundTasks,
    package_id: UUID,
    payload: RejectionInput,
) -> SuccessResponse[PackageRead]:
    return SuccessResponse(
        message=PackageMessages.PACKAGE_REJECTED,
        data=PackageApprovalService(db, background_tasks).reject(
            business, package_id, payload, actor
        ),
    )


@router.get(
    "/businesses/{business_id}/package-default-price",
    response_model=SuccessResponse[DefaultPriceRead],
)
def get_default_price(
    _: PackageViewerDep, business: BusinessDep, db: DbSessionDep
) -> SuccessResponse[DefaultPriceRead]:
    return SuccessResponse(
        message=PackageMessages.DEFAULT_PRICE_RETRIEVED,
        data=BusinessPricingService(db).get(business.id),
    )


@router.put(
    "/businesses/{business_id}/package-default-price",
    response_model=SuccessResponse[DefaultPriceRead],
)
def set_default_price(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    payload: DefaultPriceUpdate,
) -> SuccessResponse[DefaultPriceRead]:
    return SuccessResponse(
        message=PackageMessages.DEFAULT_PRICE_UPDATED,
        data=BusinessPricingService(db).set(business.id, business.owner_id, payload, actor),
    )


@router.get(
    "/businesses/{business_id}/package-category",
    response_model=SuccessResponse[PackageCategoryRead],
)
def get_package_category(
    _: PackageViewerDep, business: BusinessDep, db: DbSessionDep
) -> SuccessResponse[PackageCategoryRead]:
    return SuccessResponse(
        message=PackageMessages.CATEGORY_CONFIG_RETRIEVED,
        data=PackageConfigService(db).get(business.id),
    )


@router.put(
    "/businesses/{business_id}/package-category",
    response_model=SuccessResponse[PackageCategoryRead],
)
def set_package_category(
    actor: PackageManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    payload: PackageCategoryUpdate,
) -> SuccessResponse[PackageCategoryRead]:
    return SuccessResponse(
        message=PackageMessages.CATEGORY_CONFIG_UPDATED,
        data=PackageConfigService(db).set(business.id, business.owner_id, payload.category, actor),
    )
