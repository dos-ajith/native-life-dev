from .config import WIZARD_STEP_COUNT
from .models import Package
from .route_rules import media_complete, route_point_count_valid

PREVIEW_STEP = WIZARD_STEP_COUNT + 1


def completed_steps(package: Package) -> list[int]:
    checks = (
        route_point_count_valid(package.category, len(package.route_points)),
        media_complete(package),
        package.business_id is not None,
        package.direct_value is not None and package.package_price is not None,
        package.primary_location_id is not None,
    )
    return [step for step, done in enumerate(checks, start=1) if done]


def next_step(package: Package) -> int:
    done = set(completed_steps(package))
    return next(
        (step for step in range(1, WIZARD_STEP_COUNT + 1) if step not in done), PREVIEW_STEP
    )
