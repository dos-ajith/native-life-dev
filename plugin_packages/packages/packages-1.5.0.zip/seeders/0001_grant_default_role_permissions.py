import tomllib
import uuid
from pathlib import Path

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.engine import Connection

MANIFEST_PATH = Path(__file__).resolve().parent.parent / "plugin.toml"
PACKAGES_VIEW = "plugin.packages.packages.view"
PACKAGES_MANAGE = "plugin.packages.packages.manage"
ORDERS_VIEW = "plugin.packages.orders.view"
ROLE_GRANTS = {
    "promoter": (PACKAGES_VIEW, PACKAGES_MANAGE, ORDERS_VIEW),
    "business-service-provider": (PACKAGES_VIEW, PACKAGES_MANAGE, ORDERS_VIEW),
    "native-admin": (PACKAGES_VIEW, ORDERS_VIEW),
    "super-admin": (PACKAGES_VIEW, ORDERS_VIEW),
}

PERMISSIONS = sa.table(
    "permissions",
    sa.column("id", sa.Uuid()),
    sa.column("name", sa.String()),
    sa.column("description", sa.String()),
)
ROLES = sa.table("roles", sa.column("id", sa.Uuid()), sa.column("slug", sa.String()))
ROLE_PERMISSIONS = sa.table(
    "role_has_permissions", sa.column("role_id", sa.Uuid()), sa.column("permission_id", sa.Uuid())
)


def _declared_permissions() -> dict[str, str]:
    manifest = tomllib.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    return {
        name: declaration["description"] for name, declaration in manifest["permissions"].items()
    }


def seed(connection: Connection) -> None:
    declared = _declared_permissions()
    connection.execute(
        insert(PERMISSIONS)
        .values(
            [
                {"id": uuid.uuid4(), "name": name, "description": description}
                for name, description in declared.items()
            ]
        )
        .on_conflict_do_nothing(index_elements=["name"])
    )
    permission_ids: dict[str, uuid.UUID] = {
        name: permission_id
        for permission_id, name in connection.execute(
            sa.select(PERMISSIONS.c.id, PERMISSIONS.c.name).where(PERMISSIONS.c.name.in_(declared))
        )
    }
    role_ids: dict[str, uuid.UUID] = {
        slug: role_id
        for role_id, slug in connection.execute(
            sa.select(ROLES.c.id, ROLES.c.slug).where(ROLES.c.slug.in_(ROLE_GRANTS))
        )
    }
    rows = [
        {"role_id": role_ids[slug], "permission_id": permission_ids[name]}
        for slug, names in ROLE_GRANTS.items()
        if slug in role_ids
        for name in names
    ]
    if rows:
        connection.execute(insert(ROLE_PERMISSIONS).values(rows).on_conflict_do_nothing())
