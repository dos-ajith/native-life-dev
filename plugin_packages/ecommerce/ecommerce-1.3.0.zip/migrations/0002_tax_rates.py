from typing import Any

import sqlalchemy as sa
from alembic.operations import Operations

PREFIX = "plg_ecommerce_"
NOW = sa.text("now()")


def _timestamps() -> list[sa.Column[Any]]:
    return [
        sa.Column("created_at", sa.DateTime(), server_default=NOW, nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=NOW, nullable=False),
    ]


def _tax_rate_fk() -> sa.ForeignKey:
    return sa.ForeignKey(f"{PREFIX}tax_rates.id", ondelete="SET NULL")


def upgrade(op: Operations) -> None:
    op.create_table(
        f"{PREFIX}tax_rates",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column(
            "business_id",
            sa.Uuid(),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("rate_percent", sa.Numeric(5, 2), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        *_timestamps(),
        sa.UniqueConstraint("business_id", "name", name=f"uq_{PREFIX}tax_rates_business_name"),
    )
    op.add_column(
        f"{PREFIX}products", sa.Column("tax_rate_id", sa.Uuid(), _tax_rate_fk(), nullable=True)
    )
    op.add_column(
        f"{PREFIX}settings",
        sa.Column("default_tax_rate_id", sa.Uuid(), _tax_rate_fk(), nullable=True),
    )
