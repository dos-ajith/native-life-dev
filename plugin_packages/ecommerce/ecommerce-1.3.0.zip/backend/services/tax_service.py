from decimal import Decimal
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.plugins.sdk import ConflictError, NotFoundError, User, record_activity

from ..activity_actions import EcommerceAction, EcommerceEntity
from ..database_errors import is_unique_violation
from ..messages import EcommerceMessages
from ..models import Product, TaxRate
from ..repositories.settings_repository import SettingsRepository
from ..repositories.tax_repository import TaxRepository
from ..schemas.tax import TaxRateCreate, TaxRateRead, TaxRateUpdate

NO_TAX = Decimal(0)


def effective_tax_percent(product: Product, default_percent: Decimal) -> Decimal:
    rate = product.tax_rate
    if rate is not None and rate.is_active:
        return rate.rate_percent
    return default_percent


class TaxService:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._rates = TaxRepository(db)
        self._settings = SettingsRepository(db)

    def list_rates(self, business_id: UUID) -> list[TaxRateRead]:
        return [
            TaxRateRead.model_validate(rate) for rate in self._rates.list_for_business(business_id)
        ]

    def create(self, business_id: UUID, payload: TaxRateCreate, actor: User) -> TaxRateRead:
        name = payload.name.strip()
        if self._rates.get_by_name(business_id, name) is not None:
            raise ConflictError(EcommerceMessages.TAX_RATE_EXISTS)
        rate = self._rates.add(
            TaxRate(business_id=business_id, name=name, rate_percent=payload.rate_percent)
        )
        self._commit_unique()
        self._log(actor, EcommerceAction.TAX_RATE_CREATED, rate, business_id)
        return TaxRateRead.model_validate(rate)

    def update(
        self, business_id: UUID, rate_id: UUID, payload: TaxRateUpdate, actor: User
    ) -> TaxRateRead:
        rate = self.require(business_id, rate_id)
        changed: list[str] = []
        if payload.name is not None and payload.name.strip() != rate.name:
            name = payload.name.strip()
            if self._rates.get_by_name(business_id, name) is not None:
                raise ConflictError(EcommerceMessages.TAX_RATE_EXISTS)
            rate.name = name
            changed.append("name")
        if payload.rate_percent is not None and payload.rate_percent != rate.rate_percent:
            rate.rate_percent = payload.rate_percent
            changed.append("rate_percent")
        if payload.is_active is not None and payload.is_active != rate.is_active:
            rate.is_active = payload.is_active
            changed.append("is_active")
        if changed:
            self._commit_unique()
            self._log(actor, EcommerceAction.TAX_RATE_UPDATED, rate, business_id, changed)
        return TaxRateRead.model_validate(rate)

    def require(self, business_id: UUID, rate_id: UUID) -> TaxRate:
        rate = self._rates.get(business_id, rate_id)
        if rate is None:
            raise NotFoundError(EcommerceMessages.TAX_RATE_NOT_FOUND)
        return rate

    def default_percent(self, business_id: UUID) -> Decimal:
        settings = self._settings.get(business_id)
        if settings is None or settings.default_tax_rate_id is None:
            return NO_TAX
        rate = self._rates.get(business_id, settings.default_tax_rate_id)
        return rate.rate_percent if rate is not None and rate.is_active else NO_TAX

    def _commit_unique(self) -> None:
        try:
            self._db.commit()
        except IntegrityError as exc:
            self._db.rollback()
            if not is_unique_violation(exc):
                raise
            raise ConflictError(EcommerceMessages.TAX_RATE_EXISTS) from exc

    def _log(
        self,
        actor: User,
        action: str,
        rate: TaxRate,
        business_id: UUID,
        changed: list[str] | None = None,
    ) -> None:
        record_activity(
            self._db,
            actor,
            action,
            EcommerceEntity.TAX_RATE,
            rate.id,
            {
                "business_id": str(business_id),
                "rate_percent": str(rate.rate_percent),
                **({"fields": changed} if changed is not None else {}),
            },
        )
