import uuid
from decimal import Decimal

from sqlalchemy import Numeric, String, UniqueConstraint, true
from sqlalchemy.orm import Mapped, mapped_column

from app.plugins.sdk import TimestampMixin, UUIDPrimaryKeyMixin

from ..config import TAX_NAME_MAX_LENGTH, TAX_PERCENT_PRECISION, TAX_PERCENT_SCALE
from .base import EcommerceBase


class TaxRate(EcommerceBase, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "plg_ecommerce_tax_rates"
    __table_args__ = (
        UniqueConstraint("business_id", "name", name="uq_plg_ecommerce_tax_rates_business_name"),
    )

    business_id: Mapped[uuid.UUID]
    name: Mapped[str] = mapped_column(String(TAX_NAME_MAX_LENGTH))
    rate_percent: Mapped[Decimal] = mapped_column(Numeric(TAX_PERCENT_PRECISION, TAX_PERCENT_SCALE))
    is_active: Mapped[bool] = mapped_column(default=True, server_default=true())
