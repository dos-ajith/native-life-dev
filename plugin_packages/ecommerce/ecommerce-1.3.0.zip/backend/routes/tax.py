from uuid import UUID

from fastapi import APIRouter

from app.plugins.sdk import DbSessionDep, SuccessResponse

from ..messages import EcommerceMessages
from ..schemas.tax import TaxRateCreate, TaxRateRead, TaxRateUpdate
from ..services.tax_service import TaxService
from .dependencies import BusinessDep, SettingsManagerDep, SettingsViewerDep

CREATED = 201

router = APIRouter()


@router.get(
    "/businesses/{business_id}/tax-rates", response_model=SuccessResponse[list[TaxRateRead]]
)
def list_tax_rates(
    _: SettingsViewerDep, business: BusinessDep, db: DbSessionDep
) -> SuccessResponse[list[TaxRateRead]]:
    return SuccessResponse(
        message=EcommerceMessages.TAX_RATES_RETRIEVED, data=TaxService(db).list_rates(business.id)
    )


@router.post(
    "/businesses/{business_id}/tax-rates",
    response_model=SuccessResponse[TaxRateRead],
    status_code=CREATED,
)
def create_tax_rate(
    actor: SettingsManagerDep, business: BusinessDep, db: DbSessionDep, payload: TaxRateCreate
) -> SuccessResponse[TaxRateRead]:
    return SuccessResponse(
        message=EcommerceMessages.TAX_RATE_CREATED,
        data=TaxService(db).create(business.id, payload, actor),
    )


@router.patch(
    "/businesses/{business_id}/tax-rates/{rate_id}",
    response_model=SuccessResponse[TaxRateRead],
)
def update_tax_rate(
    actor: SettingsManagerDep,
    business: BusinessDep,
    db: DbSessionDep,
    rate_id: UUID,
    payload: TaxRateUpdate,
) -> SuccessResponse[TaxRateRead]:
    return SuccessResponse(
        message=EcommerceMessages.TAX_RATE_UPDATED,
        data=TaxService(db).update(business.id, rate_id, payload, actor),
    )
