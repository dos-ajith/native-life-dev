from datetime import datetime
from decimal import Decimal
from typing import Annotated
from uuid import UUID

from pydantic import BaseModel, Field

from app.plugins.sdk import BaseReadSchema

from ..config import TAX_MAX_PERCENT, TAX_NAME_MAX_LENGTH, TAX_PERCENT_SCALE

TaxName = Annotated[str, Field(min_length=1, max_length=TAX_NAME_MAX_LENGTH)]
TaxPercent = Annotated[
    Decimal, Field(ge=0, le=TAX_MAX_PERCENT, decimal_places=TAX_PERCENT_SCALE, max_digits=5)
]


class TaxRateCreate(BaseModel):
    name: TaxName
    rate_percent: TaxPercent


class TaxRateUpdate(BaseModel):
    name: TaxName | None = None
    rate_percent: TaxPercent | None = None
    is_active: bool | None = None


class TaxRateRead(BaseReadSchema):
    id: UUID
    business_id: UUID
    name: str
    rate_percent: Decimal
    is_active: bool
    created_at: datetime
    updated_at: datetime
