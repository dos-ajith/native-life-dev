from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import TaxRate


class TaxRepository:
    def __init__(self, db: Session) -> None:
        self._db = db

    def get(self, business_id: UUID, rate_id: UUID) -> TaxRate | None:
        return self._db.scalar(
            select(TaxRate)
            .where(TaxRate.id == rate_id, TaxRate.business_id == business_id)
            .execution_options(populate_existing=True)
        )

    def get_by_name(self, business_id: UUID, name: str) -> TaxRate | None:
        return self._db.scalar(
            select(TaxRate).where(TaxRate.business_id == business_id, TaxRate.name == name)
        )

    def list_for_business(self, business_id: UUID) -> list[TaxRate]:
        return list(
            self._db.scalars(
                select(TaxRate)
                .where(TaxRate.business_id == business_id)
                .order_by(TaxRate.name)
                .execution_options(populate_existing=True)
            )
        )

    def add(self, rate: TaxRate) -> TaxRate:
        self._db.add(rate)
        self._db.flush()
        return rate
